import cv2
import pygame
from py_trees.common import Status

from ..types.CameraMode import CameraMode
from .MaxineBehavior import MaxineBehavior
from ..types.RobotModes import RobotMode


class SetRobotMode(MaxineBehavior):
    """
    Behavior that sets the robot in a particular mode
    Used to switch modes
    Enhanced to handle LIDARCHASE mode with pygame display
    """

    # stores the camera mode for each robot mode
    ROBOT_MODE_TO_CAMERA_MODE = {
        RobotMode.IDLE: CameraMode.DISABLED,
        RobotMode.EXIT: CameraMode.DISABLED,
        RobotMode.KEYBOARD_CONTROL: CameraMode.DISABLED,
        RobotMode.CHASE: CameraMode.OBJECT_DETECTION,
        RobotMode.LIDARCHASE: CameraMode.OBJECT_DETECTION,
        RobotMode.DISCOVERY: CameraMode.OBJECT_DETECTION,
        RobotMode.HEADTURN: CameraMode.DISABLED,
        RobotMode.DIAGNOSTIC: CameraMode.DISABLED,
        RobotMode.PLAYGAME: CameraMode.DISABLED,
        RobotMode.LIDAR_TEST: CameraMode.OBJECT_DETECTION,
    }

    MODE_SAYING = {
        RobotMode.IDLE: "idle",
        RobotMode.KEYBOARD_CONTROL: "keyboard control",
        RobotMode.CHASE: "chase",
        RobotMode.EXIT: "Exit",
        RobotMode.LIDARCHASE: "Lidar Chase Mode",
        RobotMode.DISCOVERY: "Discovery",
        RobotMode.HEADTURN: "Head Turn",
        RobotMode.DIAGNOSTIC: "Diagnostic",
        RobotMode.PLAYGAME: "Play Game",
        RobotMode.LIDAR_TEST: "Test Lidar",
    }

    def __init__(self, mode: RobotMode):
        """
        Initialises the Behavior

        arguments:
            - mode: the mode to set the robot in
        """
        super().__init__(f"Set to {mode.name} mode")
        self.mode = mode

    def safely_destroy_camera_window(self):
        """
        Safely destroy the OpenCV Camera window if it exists
        """
        try:
            if cv2.getWindowProperty("Camera", cv2.WND_PROP_VISIBLE) >= 0:
                cv2.destroyWindow("Camera")
        except cv2.error:
            pass
        except Exception:
            pass

    def initialize_pygame_for_lidarchase(self):
        """
        Initialize pygame for LIDARCHASE mode if needed
        """
        if self.mode == RobotMode.LIDARCHASE:
            try:
                if not pygame.get_init():
                    pygame.init()
                    print("🎮 Pygame initialized for LiDAR display")
                return True
            except Exception as e:
                print(f"⚠️ Pygame initialization warning: {e}")
                return False
        return True

    def initialize_lidar_system(self):
        """
        Initialize LiDAR system for LIDARCHASE mode
        """
        if self.mode == RobotMode.LIDARCHASE:
            try:
                robot = self.get_robot()
                
                if hasattr(robot, 'lidar_sensor') and robot.lidar_sensor:
                    print("🚀 Initializing LiDAR system...")
                    
                    if robot.lidar_sensor.initialize():
                        print("✅ LiDAR system initialized - motor spinning")
                        return True
                    else:
                        print("❌ Failed to initialize LiDAR system")
                        return False
                else:
                    print("❌ No LiDAR sensor available")
                    return False
                    
            except Exception as e:
                print(f"❌ LiDAR initialization error: {e}")
                return False
        return True

    def cleanup_pygame_for_other_modes(self):
        """
        Clean up pygame when leaving LIDARCHASE mode
        """
        if self.mode != RobotMode.LIDARCHASE and pygame.get_init():
            try:
                pygame.event.clear()
                
                if pygame.display.get_init():
                    try:
                        screen = pygame.display.get_surface()
                        if screen:
                            screen.fill((0, 0, 0))
                            pygame.display.flip()
                    except Exception:
                        pass
                
                print("🖥️ Pygame display cleared")
            except Exception as e:
                print(f"⚠️ Pygame cleanup warning: {e}")

    def shutdown_lidar_system(self):
        """
        Shutdown LiDAR system when leaving LIDARCHASE mode
        """
        if self.mode != RobotMode.LIDARCHASE:
            try:
                robot = self.get_robot()
                
                if hasattr(robot, 'lidar_sensor') and robot.lidar_sensor:
                    print("🛑 Shutting down LiDAR system...")
                    robot.lidar_sensor.shutdown()
                    print("✅ LiDAR system shutdown complete")
                    
            except Exception as e:
                print(f"⚠️ LiDAR shutdown warning: {e}")

    def update_camera(self):
        """
        Handles updating the camera sensor related settings upon changing robot mode
        Enhanced for LIDARCHASE mode
        """
        robot = self.get_robot()

        # switch the camera mode on camera sensor
        camera_mode = self.ROBOT_MODE_TO_CAMERA_MODE[self.mode]
        robot.camera_sensor.switch_mode(camera_mode)

        # close the camera window safely
        self.safely_destroy_camera_window()

        # Initialize pygame for LIDARCHASE mode
        if self.mode == RobotMode.LIDARCHASE:
            self.initialize_pygame_for_lidarchase()
            self.initialize_lidar_system()
        else:
            self.cleanup_pygame_for_other_modes()
            self.shutdown_lidar_system()

        # open camera window if required (for non-LIDARCHASE modes)
        if camera_mode != CameraMode.DISABLED and self.mode != RobotMode.LIDARCHASE:
            pass
   
    def update(self) -> Status:
        # set the robot mode
        robot = self.get_robot()
        robot.set_mode(self.mode)
        
        # Enhanced speech for LIDARCHASE mode
        speech_text = self.MODE_SAYING[self.mode]
        
        robot.speech_manager.perform_action(speech_text)

        print(f"Setting to {self.mode}")

        # clear keyboard sensor currently pressed keys when switching modes
        robot.keyboard_sensor.flush_readings()

        # update the camera settings AND initialize LiDAR
        self.update_camera()

        # Additional setup for LIDARCHASE mode
        if self.mode == RobotMode.LIDARCHASE:
            print("🎯 LiDAR Chase mode activated")

        # this behavior always passes
        return Status.SUCCESS