import time
import threading
from typing import List, Optional
import depthai as dai
import py_trees
from py_trees.common import Status
from py_trees.composites import Selector, Sequence

from src.behaviors.MaxineBehavior import MaxineBehavior
from src.behaviors.SetRobotMode import SetRobotMode
from src.behaviors.chase_mode.SelectPerson import SelectPerson
from src.behaviors.chase_mode.HasReachedPerson import HasReachedPerson
from src.behaviors.chase_mode.AnnounceFoundPerson import AnnounceFoundPerson
from src.behaviors.lidarchase.LidarChaseBehavior import LidarChaseBehavior
from src.types.RobotModes import RobotMode
from src.types.MovementDirection import MovementDirection
from src.action_managers.VelocityManager import VelocityConfig
from ..MoveBehavior import MoveBehavior


class PersonDetectionBehavior(MaxineBehavior):
    """Enhanced person detection for LiDAR chase"""
    
    def __init__(self):
        super().__init__("Enhanced Person Detection")
        self.blackboard.register_key("TARGET_PERSON", access=py_trees.common.Access.WRITE)
        self.person_detector = SelectPerson()
    
    def update(self) -> Status:
        return self.person_detector.update()


class TargetReachedHandler(MaxineBehavior):
    """Handle when target is reached"""
    
    def __init__(self, threshold_mm=500):
        super().__init__("Target Reached Handler")
        self.threshold_mm = threshold_mm
        self.blackboard.register_key("TARGET_PERSON", access=py_trees.common.Access.READ)
        
        # Sub-behaviors
        self.has_reached = HasReachedPerson(threshold_mm)
        self.announcer = AnnounceFoundPerson()
        
        self.sequence_complete = False
    
    def update(self) -> Status:
        try:
            # Check if target reached
            reach_status = self.has_reached.update()
            
            if reach_status == Status.SUCCESS:
                # Stop robot
                robot = self.get_robot()
                if robot.velocity_manager:
                    stop_config = VelocityConfig(MovementDirection.NONE, 0.0)
                    robot.velocity_manager.perform_action(stop_config)
                
                # Announce success
                if not self.sequence_complete:
                    announce_status = self.announcer.update()
                    if announce_status == Status.SUCCESS:
                        self.sequence_complete = True
                        print("🎯 Target reached! Switching to IDLE mode...")
                        robot.set_mode(RobotMode.IDLE)
                        return Status.SUCCESS
                    return Status.RUNNING
                else:
                    return Status.SUCCESS
            else:
                self.sequence_complete = False
                return Status.FAILURE
                
        except Exception as e:
            print(f"❌ Target reached handler error: {e}")
            return Status.FAILURE
    
    def initialise(self):
        self.sequence_complete = False


class ExitHandler(MaxineBehavior):
    """Handle ESC key exit requests"""
    
    def __init__(self):
        super().__init__("Exit Handler")
        self.exit_requested = False
        self.exit_confirmed = False
        self.exit_start_time = 0
        self.exit_timeout = 2.0
    
    def update(self) -> Status:
        try:
            import pygame
            
            # Check for ESC key
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if not self.exit_requested:
                        print("🚪 Exit requested via ESC key")
                        self.exit_requested = True
                        self.exit_start_time = time.time()
                    return Status.SUCCESS  # Exit successful
                elif event.type == pygame.QUIT:
                    return Status.SUCCESS
            
            # Handle ongoing exit
            if self.exit_requested:
                current_time = time.time()
                if current_time - self.exit_start_time > self.exit_timeout:
                    print("✅ Exit confirmed")
                    robot = self.get_robot()
                    robot.set_mode(RobotMode.IDLE)
                    return Status.SUCCESS
                return Status.RUNNING
            
            return Status.FAILURE  # No exit requested
            
        except Exception as e:
            return Status.FAILURE


class LidarChaseController(MaxineBehavior):
    """Main controller that coordinates all LiDAR chase components"""
    
    def __init__(self):
        super().__init__("LiDAR Chase Controller")
        
        # Initialize components
        self.person_detector = PersonDetectionBehavior()
        self.lidar_chase = LidarChaseBehavior()
        self.target_handler = TargetReachedHandler(500)
        self.exit_handler = ExitHandler()
        
        # State tracking
        self.components_initialized = False
        self.current_component = None
        
        print("🎮 LiDAR Chase Controller initialized")
    
    def initialize_components(self):
        """Initialize all components"""
        if not self.components_initialized:
            try:
                # Initialize person detection
                self.person_detector.initialise()
                
                # Initialize LiDAR chase
                self.lidar_chase.initialise()
                
                # Initialize target handler
                self.target_handler.initialise()
                
                self.components_initialized = True
                print("✅ All LiDAR chase components initialized")
                return True
                
            except Exception as e:
                print(f"❌ Component initialization error: {e}")
                return False
        return True
    
    def update(self) -> Status:
        try:
            # Initialize components if needed
            if not self.initialize_components():
                return Status.FAILURE
            
            # Check for exit first (highest priority)
            exit_status = self.exit_handler.update()
            if exit_status == Status.SUCCESS:
                print("🚪 Exiting LiDAR chase mode")
                return Status.SUCCESS  # Exit to IDLE
            
            # Check if target reached (second priority)
            target_status = self.target_handler.update()
            if target_status == Status.SUCCESS:
                print("🎯 Target reached, mission complete")
                return Status.SUCCESS  # Mission complete
            
            # Run person detection (always active)
            person_status = self.person_detector.update()
            
            # Run main LiDAR chase behavior
            chase_status = self.lidar_chase.update()
            
            # Continue running if chase is active
            if chase_status == Status.RUNNING:
                return Status.RUNNING
            elif chase_status == Status.FAILURE:
                print("❌ LiDAR chase failed")
                return Status.FAILURE
            else:
                return Status.RUNNING  # Keep running
            
        except Exception as e:
            print(f"❌ LiDAR chase controller error: {e}")
            return Status.FAILURE
    
    def terminate(self, new_status: Status):
        """Clean termination of all components"""
        try:
            print("🧹 Terminating LiDAR chase controller...")
            
            # Terminate all components
            if hasattr(self, 'lidar_chase'):
                self.lidar_chase.terminate(new_status)
            
            if hasattr(self, 'person_detector'):
                self.person_detector.terminate(new_status)
            
            if hasattr(self, 'target_handler'):
                self.target_handler.terminate(new_status)
            
            print("✅ LiDAR chase controller terminated")
            
        except Exception as e:
            print(f"❌ Termination error: {e}")
        
        super().terminate(new_status)


class SimpleLidarChaseTree(Selector):
    """
    Complete LiDAR chase behavior tree
    Handles all aspects: person detection, navigation, target reached, exit
    """
    
    def __init__(self):
        super().__init__("Complete LiDAR Chase Tree", memory=True)
        
        # Create the main controller
        self.controller = LidarChaseController()
        
        # Set as only child - controller handles everything
        self.children = [self.controller]
        
        print("🌳 Complete LiDAR Chase Tree created")
    
    def terminate(self, new_status: Status):
        """Clean termination"""
        try:
            if self.controller:
                self.controller.terminate(new_status)
        except Exception as e:
            print(f"❌ Tree termination error: {e}")
        
        super().terminate(new_status)


# Alternative implementation with explicit sequence
class SequentialLidarChaseTree(Sequence):
    """Alternative implementation using explicit sequence"""
    
    def __init__(self):
        super().__init__("Sequential LiDAR Chase", memory=True)
        
        # Create components
        person_detection = PersonDetectionBehavior()
        main_chase = LidarChaseBehavior()
        
        # Set up children
        self.children = [
            person_detection,
            main_chase
        ]


# Factory functions
def create_lidar_chase_behavior_tree():
    """Create the complete LiDAR chase behavior tree"""
    return SimpleLidarChaseTree()


def create_sequential_lidar_chase_tree():
    """Create sequential version of LiDAR chase tree"""
    return SequentialLidarChaseTree()


def create_minimal_lidar_chase():
    """Create minimal LiDAR chase - just the core behavior"""
    return LidarChaseBehavior()


# Main factory function for external use
def make_lidar_chase_sub_tree():
    """
    Main factory function for creating LiDAR chase behavior tree
    This is the primary function to use in your main behavior tree
    """
    return create_lidar_chase_behavior_tree()