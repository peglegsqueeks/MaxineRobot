from typing import List
from .ObjectDetectionPipeline import ObjectDetectionPipeline
from .CameraReading import CameraReading

import depthai as dai
import cv2
import numpy as np


class ObjectDetectionReading2(CameraReading):
    """
    Camera reading from Object Detection Camera mode
    """

    # the key to get the image from
    IMAGE_KEY = ObjectDetectionPipeline.ObjectDetectionQueues.IMAGE_OUT

    # the labels from object detection
    LABEL_MAP = [
        "background",
        "aeroplane",
        "bicycle",
        "bird",
        "boat",
        "bottle",
        "bus",
        "car",
        "cat",
        "chair",
        "cow",
        "diningtable",
        "dog",
        "horse",
        "motorbike",
        "person",
        "pottedplant",
        "sheep",
        "sofa",
        "train",
        "tvmonitor",
    ]

    def get_people_locations(self) -> List[dai.SpatialImgDetection]:
        """Get only person detections"""
        objects = self.queue_readings[
            ObjectDetectionPipeline.ObjectDetectionQueues.OBJECT_OUT
        ]
        people = []
        for object in objects.detections:
            if self.LABEL_MAP[object.label] == "person":
                people.append(object)
        return people
    
    def get_object_locations(self) -> List[dai.SpatialImgDetection]:
        """Get all object detections"""
        objects = self.queue_readings[
            ObjectDetectionPipeline.ObjectDetectionQueues.OBJECT_OUT
        ]
        allobjects = []
        for object in objects.detections:
            allobjects.append(object)
        return allobjects

    def get_frame(self):
        """
        Ovverides the get_frame function by plotting a bounding box of detected objects along with their label
        """
        # get the base image from parent class
        base_frame = super().get_frame()

        # converts an x, y to a coordinate on the image
        def point_to_image_coord(x, y):
            return (np.array((x, y)).clip(0, 1) * base_frame.shape[:2]).astype(np.int32)

        objects = self.queue_readings[
            ObjectDetectionPipeline.ObjectDetectionQueues.OBJECT_OUT
        ]

        # red, blue, green
        colors = ((255, 0, 0), (0, 255, 0), (0, 0, 255))

        for color, object in zip(colors, objects.detections):
            # get bounding box coordinates
            start_point = point_to_image_coord(object.xmin, object.ymin)
            end_point = point_to_image_coord(object.xmax, object.ymax)

            # build label text
            label = self.LABEL_MAP[object.label]
            confidence = object.confidence
            text = f"{label} ({round(confidence, 2)})"

            # add bounding box rectangle on image
            base_frame = cv2.rectangle(
                base_frame,
                start_point,
                end_point,
                color=color,
                thickness=1,
            )

            # add label on image
            base_frame = cv2.putText(
                base_frame,
                text,
                start_point + np.array((0, 20)),
                cv2.FONT_HERSHEY_TRIPLEX,
                0.5,
                color,
            )

        return base_frame