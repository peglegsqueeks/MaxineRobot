import time
import threading
import UltraBorg


class PIDController:
    """
    PID Controller for smooth servo movements
    """
    def __init__(self, kp=2.0, ki=0.1, kd=0.05, max_output=0.05):
        self.kp = kp          # Proportional gain
        self.ki = ki          # Integral gain  
        self.kd = kd          # Derivative gain
        self.max_output = max_output  # Maximum step size per update
        
        self.previous_error = 0.0
        self.integral = 0.0
        self.last_time = time.time()
        
    def reset(self):
        """Reset PID controller state"""
        self.previous_error = 0.0
        self.integral = 0.0
        self.last_time = time.time()
        
    def update(self, setpoint, current_value):
        """
        Calculate PID output
        
        arguments:
            - setpoint: Target position
            - current_value: Current position
            
        returns:
            - output: PID output (step to take)
        """
        current_time = time.time()
        dt = current_time - self.last_time
        
        if dt <= 0.0:
            dt = 0.01  # Prevent division by zero
            
        # Calculate error
        error = setpoint - current_value
        
        # Proportional term
        proportional = self.kp * error
        
        # Integral term (with windup protection)
        self.integral += error * dt
        self.integral = max(-1.0, min(1.0, self.integral))  # Clamp integral
        integral = self.ki * self.integral
        
        # Derivative term
        derivative = self.kd * (error - self.previous_error) / dt
        
        # Calculate output
        output = proportional + integral + derivative
        
        # Limit output to prevent sudden movements
        output = max(-self.max_output, min(self.max_output, output))
        
        # Update for next iteration
        self.previous_error = error
        self.last_time = current_time
        
        return output


class ServoController:
    """
    Enhanced servo controller with PID control for smooth, safe head movements
    Protects the 4kg head assembly from damage due to sudden movements
    """

    def __init__(self, i2c_address: int = 11):
        """
        Initialize the servo controller with PID control
        
        arguments:
            - i2c_address: I2C address of the UltraBorg board (default 11, which is 0x0b in hex)
        """
        self.i2c_address = i2c_address
        self.board = None
        self.is_initialized = False
        
        # Servo position limits (-90 to +90 degrees, represented as -0.98 to +0.98)
        self.min_position = -0.98  # Full left (-90 degrees)
        self.max_position = 0.98   # Full right (+90 degrees)
        self.current_position = 0.0  # Current servo position
        self.target_position = 0.0   # Target servo position
        
        # PID Controller for smooth movements
        # Tuned for 4kg head - conservative values to prevent damage
        self.pid = PIDController(
            kp=1.5,      # Proportional gain - moderate for stability
            ki=0.05,     # Integral gain - low to prevent oscillation
            kd=0.08,     # Derivative gain - helps damping
            max_output=0.02  # Maximum step size - small for safety
        )
        
        # Movement control
        self.movement_thread = None
        self.movement_active = False
        self.movement_lock = threading.Lock()
        self.position_tolerance = 0.01  # How close to target before stopping
        self.update_rate = 0.05  # Update every 50ms for smooth movement
        
    def initialize(self):
        """
        Initialize the UltraBorg board and center the head properly
        """
        try:
            print(f"🔧 Initializing UltraBorg at I2C address {self.i2c_address} (0x{self.i2c_address:02x})")
            
            self.board = UltraBorg.UltraBorg()
            self.board.i2cAddress = self.i2c_address
            self.board.Init()
            
            if not self.board.foundChip:
                print(f"❌ UltraBorg not found at address {self.i2c_address} (0x{self.i2c_address:02x})")
                return False
            
            print(f"✅ UltraBorg found at address {self.i2c_address} (0x{self.i2c_address:02x})")
            
            # Configure servo limits and startup position
            print("🔧 Configuring servo parameters...")
            self.board.SetWithRetry(self.board.SetServoMaximum3, self.board.GetServoMaximum3, 5085, 5)
            self.board.SetWithRetry(self.board.SetServoMinimum3, self.board.GetServoMinimum3, 1550, 5)
            self.board.SetWithRetry(self.board.SetServoStartup3, self.board.GetServoStartup3, 3565, 5)
            
            print("✅ Servo parameters configured")
            
            # Get current position
            self.current_position = self.board.GetServoPosition3()
            if self.current_position is None:
                self.current_position = 0.0
                
            print(f"📍 Current head position: {self.current_position:.3f}")
            
            self.is_initialized = True
            
            # Center the head with PID control for smooth movement
            print("🎯 Centering head to zero position...")
            if self.center_head_smooth():
                print("✅ Head successfully centered")
            else:
                print("⚠️ Head centering completed with warnings")
            
            return True
            
        except Exception as e:
            print(f"❌ Error initializing UltraBorg: {e}")
            self.is_initialized = False
            return False
    
    def center_head_smooth(self):
        """
        Smoothly center the head to zero position using PID control
        """
        if not self.is_initialized:
            print("⚠️ Cannot center head - servo controller not initialized")
            return False
            
        try:
            print("🎯 Starting smooth head centering...")
            
            # Get accurate current position
            current_pos = self.board.GetServoPosition3()
            if current_pos is None:
                current_pos = 0.0
                
            self.current_position = current_pos
            print(f"📍 Starting position: {self.current_position:.3f}")
            
            # Reset PID controller
            self.pid.reset()
            
            # Smoothly move to center (0.0)
            target = 0.0
            max_iterations = 200  # Safety limit
            iteration = 0
            
            while abs(self.current_position - target) > self.position_tolerance and iteration < max_iterations:
                # Get current position
                self.current_position = self.board.GetServoPosition3()
                if self.current_position is None:
                    break
                    
                # Calculate PID output
                pid_output = self.pid.update(target, self.current_position)
                
                # Apply movement
                new_position = self.current_position + pid_output
                new_position = max(self.min_position, min(self.max_position, new_position))
                
                # Set new position
                self.board.SetServoPosition3(new_position)
                
                # Small delay for smooth movement
                time.sleep(self.update_rate)
                
                iteration += 1
                
                # Progress feedback every 20 iterations
                if iteration % 20 == 0:
                    print(f"🎯 Centering progress: {abs(self.current_position - target):.3f} from target")
            
            # Final position check
            final_position = self.board.GetServoPosition3()
            if final_position is not None:
                self.current_position = final_position
                
            print(f"✅ Head centering complete. Final position: {self.current_position:.3f}")
            print(f"🎯 Centering accuracy: ±{abs(self.current_position):.3f}")
            
            # Set target to match current position
            self.target_position = self.current_position
            
            return abs(self.current_position) <= self.position_tolerance * 2  # Allow some tolerance
            
        except Exception as e:
            print(f"❌ Error during head centering: {e}")
            return False
    
    def _movement_thread_function(self):
        """
        Background thread function for smooth PID-controlled movement
        """
        try:
            while self.movement_active:
                with self.movement_lock:
                    if not self.movement_active:
                        break
                        
                    # Get current position
                    current_pos = self.board.GetServoPosition3()
                    if current_pos is not None:
                        self.current_position = current_pos
                    
                    # Check if we've reached the target
                    error = abs(self.target_position - self.current_position)
                    if error <= self.position_tolerance:
                        # Target reached, can stop moving
                        continue
                    
                    # Calculate PID output
                    pid_output = self.pid.update(self.target_position, self.current_position)
                    
                    # Apply movement
                    new_position = self.current_position + pid_output
                    new_position = max(self.min_position, min(self.max_position, new_position))
                    
                    # Set new position
                    self.board.SetServoPosition3(new_position)
                
                # Sleep for smooth update rate
                time.sleep(self.update_rate)
                
        except Exception as e:
            print(f"⚠️ Error in movement thread: {e}")
        finally:
            self.movement_active = False
    
    def set_position(self, position: float):
        """
        Set servo position with smooth PID-controlled movement
        
        arguments:
            - position: Target position (-0.98 to +0.98)
        """
        if not self.is_initialized:
            print("⚠️ Cannot set position - servo controller not initialized")
            return False
            
        # Clamp position to valid range
        position = max(self.min_position, min(self.max_position, position))
        
        try:
            with self.movement_lock:
                self.target_position = position
                
                # Reset PID for new target
                self.pid.reset()
                
                # Start movement thread if not already running
                if not self.movement_active:
                    self.movement_active = True
                    self.movement_thread = threading.Thread(target=self._movement_thread_function, daemon=True)
                    self.movement_thread.start()
            
            return True
            
        except Exception as e:
            print(f"❌ Error setting servo position: {e}")
            return False
    
    def set_position_immediate(self, position: float):
        """
        Set servo position immediately without PID (use with caution!)
        Only for emergency stops or when PID is not needed
        """
        if not self.is_initialized:
            return False
            
        position = max(self.min_position, min(self.max_position, position))
        
        try:
            # Stop any ongoing movement
            with self.movement_lock:
                self.movement_active = False
                
            self.board.SetServoPosition3(position)
            self.current_position = position
            self.target_position = position
            return True
            
        except Exception as e:
            return False
    
    def wait_for_position(self, timeout=10.0):
        """
        Wait for servo to reach target position
        
        arguments:
            - timeout: Maximum time to wait in seconds
            
        returns:
            - True if position reached, False if timeout
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            error = abs(self.target_position - self.current_position)
            if error <= self.position_tolerance:
                return True
            time.sleep(0.1)
            
        return False
    
    def get_position(self):
        """
        Get current servo position from hardware
        """
        if not self.is_initialized:
            return self.current_position
            
        try:
            position = self.board.GetServoPosition3()
            if position is not None:
                self.current_position = position
                return position
            else:
                return self.current_position
        except Exception as e:
            print(f"⚠️ Error getting servo position: {e}")
            return self.current_position
    
    def get_head_position(self):
        """
        Compatibility method for existing code that calls get_head_position()
        """
        return self.get_position()
    
    def move_left(self, step_size: float = 0.1):
        """
        Move servo left by step size (with PID control)
        """
        new_position = self.target_position + step_size
        if new_position > self.max_position:
            return False
        return self.set_position(new_position)
    
    def move_right(self, step_size: float = 0.1):
        """
        Move servo right by step size (with PID control)
        """
        new_position = self.target_position - step_size
        if new_position < self.min_position:
            return False
        return self.set_position(new_position)
    
    def move_to_angle(self, angle_degrees: float):
        """
        Move to specific angle in degrees (-90 to +90) with PID control
        """
        # Convert degrees to servo position (-90° = -0.98, +90° = +0.98)
        position = (angle_degrees / 90.0) * 0.98
        return self.set_position(position)
    
    def get_angle_degrees(self):
        """
        Get current angle in degrees
        """
        return (self.current_position / 0.98) * 90.0
    
    def get_target_angle_degrees(self):
        """
        Get target angle in degrees
        """
        return (self.target_position / 0.98) * 90.0
    
    def center(self):
        """
        Center the servo (0 position) with PID control
        """
        return self.set_position(0.0)
    
    def stop_movement(self):
        """
        Stop any ongoing movement and hold current position
        """
        with self.movement_lock:
            self.movement_active = False
            self.target_position = self.current_position
            
    def shutdown(self):
        """
        Shutdown servo controller - center servo smoothly and cleanup
        """
        if self.is_initialized:
            try:
                print("🔧 Shutting down servo controller...")
                
                # Stop any movement
                self.stop_movement()
                
                # Wait a bit for movement to stop
                time.sleep(0.2)
                
                # Center servo smoothly before shutdown
                print("🎯 Centering head for shutdown...")
                self.center()
                self.wait_for_position(timeout=5.0)
                
                print("✅ Servo centered for shutdown")
                
            except Exception as e:
                print(f"⚠️ Error during servo shutdown: {e}")
                
        # Stop movement thread
        with self.movement_lock:
            self.movement_active = False
            
        if self.movement_thread and self.movement_thread.is_alive():
            self.movement_thread.join(timeout=1.0)
                
        self.is_initialized = False
        print("✅ Servo controller shutdown complete")
    
    def get_status(self):
        """
        Get detailed status information for debugging
        """
        return {
            'initialized': self.is_initialized,
            'current_position': self.current_position,
            'target_position': self.target_position,
            'current_angle_deg': self.get_angle_degrees(),
            'target_angle_deg': self.get_target_angle_degrees(),
            'movement_active': self.movement_active,
            'position_error': abs(self.target_position - self.current_position)
        }