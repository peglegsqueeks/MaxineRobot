from .ActionManager import ActionManager
from typing import TypeVar

ActionConfig = TypeVar("ActionConfig")


class DebugActionManager(ActionManager[ActionConfig]):
    """
    Implementation for a debug Action Manager
    This action manager just prints the action being taken instead of taking an action
    Useful to test with a raspberry pi missing actuators
    Will be used when the action_manager's debug: True is in config.
    """

    def perform_action(self, config: ActionConfig):
        print(f"{self.name} peforming action: {str(config)}")
