from ..depth_ai.CameraReading import CameraReading
from ..depth_ai.ObjectDetectionReading import ObjectDetectionReading
from ..types.CameraMode import CameraMode
from ..depth_ai.DepthAiPipeline import DepthAiPipeline
from ..depth_ai.ObjectDetectionPipeline import ObjectDetectionPipeline
from ..sensors.RobotSensor import RobotSensor
import depthai as dai


class CameraSensor(RobotSensor):
    """
    The camera sensor runs different pipelines on the oak camera based on the current mode
    Enhanced to support dual mono cameras with depth perception and person tracking
    """

    # mappings between camera mode and the pipeline/reading types
    MODE_PIPELINES = {CameraMode.OBJECT_DETECTION: ObjectDetectionPipeline()}
    MODE_READINGS = {CameraMode.OBJECT_DETECTION: ObjectDetectionReading}

    def __init__(self, starting_mode: CameraMode = CameraMode.DISABLED) -> None:
        """
        Initialises the camera with dual mono camera support
        """
        super().__init__("Camera")
        self.device = None
        self.current_mode = CameraMode.DISABLED
        self.output_queues = {}
        self.camera_info = {}
        self.switch_mode(starting_mode)

    def stop_camera(self):
        """
        Stops the camera pipeline from running
        """
        if self.device is not None:
            try:
                self.device.close()
            except Exception as e:
                pass
            finally:
                self.device = None
                self.output_queues = {}
                self.camera_info = {}

    def start_camera(self, pipeline: DepthAiPipeline):
        """
        Starts a pipeline on the camera with enhanced error handling
        """
        if self.device is not None:
            raise Exception(
                "Trying to start camera but camera is already started (did you forget to close the previous camera connection?)"
            )

        try:
            self.device = dai.Device()
            
            # Get camera information
            self.camera_info = {
                'device_name': self.device.getDeviceName(),
                'firmware_version': self.device.getBootloaderVersion(),
                'available_cameras': list(self.device.getConnectedCameras()),
                'usb_speed': self.device.getUsbSpeed()
            }
            
            # Start the pipeline
            self.device.startPipeline(pipeline.pipeline)
            
        except Exception as e:
            self.device = None
            self.camera_info = {}
            raise

    def switch_mode(self, mode: CameraMode):
        """
        Switch the camera mode with enhanced logging
        """
        # stop the current pipeline
        self.stop_camera()

        # if camera is disabled nothing to do
        if mode == CameraMode.DISABLED:
            self.current_mode = CameraMode.DISABLED
            return

        # Check if mode is supported
        if mode not in self.MODE_PIPELINES:
            self.current_mode = CameraMode.DISABLED
            return

        # start the relevant mode
        pipeline = self.MODE_PIPELINES[mode]
        try:
            self.start_camera(pipeline)
            self.current_mode = mode
            self.output_queues = pipeline.get_output_queues(self.device)
            
        except Exception as e:
            self.current_mode = CameraMode.DISABLED
            self.output_queues = {}

    def get_reading(self) -> CameraReading:
        """
        Returns the current reading from the pipeline with enhanced error handling
        """

        # disabled mode has no readings
        if self.current_mode == CameraMode.DISABLED:
            return None

        # Check if device is available
        if self.device is None:
            return None

        # Check if output queues exist
        if not self.output_queues:
            return None

        # get the latest reading from each queue for this mode
        readings = {}
        
        for name, queue in self.output_queues.items():
            try:
                values = queue.getAll()
                if len(values) == 0:
                    readings[name] = None
                else:
                    readings[name] = values[-1]
            except Exception as e:
                readings[name] = None

        # Check if we have a reading class for this mode
        if self.current_mode not in self.MODE_READINGS:
            return None

        # build a CameraReading object from the queue readings
        try:
            return self.MODE_READINGS[self.current_mode](readings)
        except Exception as e:
            return None

    def get_camera_info(self) -> dict:
        """
        Get information about the current camera setup
        """
        return self.camera_info.copy() if self.camera_info else {}

    def get_queue_status(self) -> dict:
        """
        Get status information about the output queues
        """
        if not self.output_queues:
            return {}
        
        status = {}
        for name, queue in self.output_queues.items():
            try:
                queue_name = name.value if hasattr(name, 'value') else str(name)
                status[queue_name] = {
                    'size': len(queue.getAll()) if queue else 0,
                    'available': queue is not None
                }
            except Exception as e:
                queue_name = name.value if hasattr(name, 'value') else str(name)
                status[queue_name] = {
                    'size': 0,
                    'available': False,
                    'error': str(e)
                }
        
        return status