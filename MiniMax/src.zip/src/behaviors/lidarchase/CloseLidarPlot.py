import time
import pygame
import threading
from src.behaviors.MaxineBehavior import MaxineBehavior
import py_trees
from py_trees.common import Status


class FixedCloseLidarPlot(MaxineBehavior):
    """
    FIXED LiDAR plot cleanup with proper display restoration for IDLE mode
    """
    
    def __init__(self):
        super().__init__("Fixed Close LiDAR Plot - Proper Display Restoration")
        
        # Blackboard keys for cleanup
        self.blackboard.register_key("LIDAR_SYSTEM", access=py_trees.common.Access.WRITE)
        self.blackboard.register_key("LIDAR_RENDERER", access=py_trees.common.Access.WRITE)
        
        # Legacy keys for backward compatibility
        self.blackboard.register_key("LIDAR_PLOT", access=py_trees.common.Access.WRITE)
        
        # Cleanup tracking
        self.cleanup_steps = []
        
    def stop_working_lidar_system(self) -> bool:
        """Stop WORKING LiDAR system with proper motor shutdown"""
        try:
            if self.blackboard.exists("LIDAR_SYSTEM"):
                lidar_system = self.blackboard.get("LIDAR_SYSTEM")
                if lidar_system:
                    print("🛑 Stopping LiDAR system...")
                    # Use the working system's stop method
                    lidar_system.stop()
                    
                    # Give time for proper shutdown
                    time.sleep(2.0)
                    
                    self.cleanup_steps.append("WORKING LiDAR system stopped")
                    print("✅ LiDAR system stopped successfully")
                
                self.blackboard.unset("LIDAR_SYSTEM")
                return True
                
        except Exception as e:
            self.cleanup_steps.append(f"WORKING LiDAR system error: {e}")
            print(f"❌ LiDAR stop error: {e}")
            return False
        
        return True
    
    def cleanup_robot_lidar_sensor(self):
        """Additional robot LiDAR sensor cleanup"""
        try:
            robot = self.get_robot()
            
            if hasattr(robot, 'lidar_sensor') and robot.lidar_sensor:
                if hasattr(robot.lidar_sensor, 'shutdown'):
                    robot.lidar_sensor.shutdown()
                    self.cleanup_steps.append("Robot LiDAR sensor shutdown")
                elif hasattr(robot.lidar_sensor, 'emergency_stop'):
                    robot.lidar_sensor.emergency_stop()
                    self.cleanup_steps.append("Robot LiDAR sensor emergency stop")
                
        except Exception as e:
            self.cleanup_steps.append(f"Robot LiDAR sensor warning: {e}")
    
    def restore_display_for_idle_mode(self) -> bool:
        """Properly restore display for IDLE mode face avatar"""
        try:
            print("🖥️ Restoring display for IDLE mode...")
            
            # Release exclusive LiDAR renderer first
            if self.blackboard.exists("LIDAR_RENDERER"):
                renderer = self.blackboard.get("LIDAR_RENDERER")
                if renderer and hasattr(renderer, 'release_display'):
                    renderer.release_display()
                    self.cleanup_steps.append("Exclusive LiDAR renderer released")
                    print("✅ Exclusive LiDAR renderer released")
                
                self.blackboard.unset("LIDAR_RENDERER")
            
            # Clear pygame display and prepare for IDLE mode
            try:
                if pygame.get_init():
                    # Get current display info
                    display_info = pygame.display.Info()
                    
                    # Create a clean fullscreen surface for IDLE mode
                    screen = pygame.display.set_mode((display_info.current_w, display_info.current_h), pygame.FULLSCREEN)
                    
                    # Fill with black and update
                    screen.fill((0, 0, 0))
                    pygame.display.flip()
                    
                    # Clear all events to prevent interference
                    pygame.event.clear()
                    
                    self.cleanup_steps.append("Display prepared for IDLE mode")
                    print("✅ Display prepared for IDLE mode face avatar")
                    return True
                    
            except Exception as display_error:
                print(f"❌ Display restoration error: {display_error}")
                self.cleanup_steps.append(f"Display error: {display_error}")
                
        except Exception as e:
            self.cleanup_steps.append(f"Display restore error: {e}")
            print(f"❌ Display restore error: {e}")
        
        return True  # Always return True to allow mode transition
    
    def cleanup_pygame_resources(self) -> bool:
        """Clean up pygame resources for mode transition"""
        try:
            if pygame.get_init():
                # Clear any remaining events
                try:
                    pygame.event.clear()
                    print("🧹 Pygame events cleared")
                except Exception:
                    pass
                
                # Don't quit pygame - IDLE mode needs it
                # Just ensure clean state
                
                self.cleanup_steps.append("Pygame resources cleaned for mode transition")
                print("✅ Pygame prepared for IDLE mode")
                return True
                
        except Exception as e:
            self.cleanup_steps.append(f"Pygame warning: {e}")
            print(f"⚠️ Pygame cleanup warning: {e}")
        
        return True
    
    def cleanup_legacy_systems(self) -> bool:
        """Clean up any legacy matplotlib systems"""
        try:
            if self.blackboard.exists("LIDAR_PLOT"):
                lidar_plot = self.blackboard.get("LIDAR_PLOT")
                if lidar_plot and hasattr(lidar_plot, 'close'):
                    lidar_plot.close()
                    self.cleanup_steps.append("Legacy matplotlib plot closed")
                
                self.blackboard.unset("LIDAR_PLOT")
                return True
                
        except Exception as e:
            self.cleanup_steps.append(f"Legacy plot warning: {e}")
        
        return True
    
    def wait_for_background_threads(self):
        """Wait for background threads to finish"""
        try:
            # Give threads time to finish
            time.sleep(1.5)
            
            # Check thread count
            active_threads = threading.active_count()
            if active_threads > 1:
                time.sleep(1.0)
            
            self.cleanup_steps.append("Background threads finished")
            print("✅ Background threads finished")
            
        except Exception as e:
            self.cleanup_steps.append(f"Thread warning: {e}")
    
    def cleanup_blackboard(self):
        """Clean up blackboard entries"""
        try:
            # Keys to clean up
            keys_to_clean = [
                "PATH", "TARGET_PERSON", "LIDAR_OBSTACLES"
            ]
            
            cleaned_count = 0
            for key in keys_to_clean:
                try:
                    if self.blackboard.exists(key):
                        self.blackboard.unset(key)
                        cleaned_count += 1
                except Exception:
                    pass
            
            if cleaned_count > 0:
                self.cleanup_steps.append(f"Cleaned {cleaned_count} blackboard entries")
                print(f"🧹 Cleaned {cleaned_count} blackboard entries")
            
        except Exception as e:
            self.cleanup_steps.append(f"Blackboard warning: {e}")
    
    def stop_robot_movement(self):
        """Ensure robot is completely stopped"""
        try:
            robot = self.get_robot()
            
            # Stop all movement
            if hasattr(robot, 'velocity_manager') and robot.velocity_manager:
                from src.types.MovementDirection import MovementDirection
                from src.action_managers.VelocityManager import VelocityConfig
                
                # Send stop commands multiple times to ensure it takes
                for _ in range(5):
                    stop_config = VelocityConfig(MovementDirection.NONE, 0.0)
                    robot.velocity_manager.perform_action(stop_config)
                    time.sleep(0.1)
                
                print("🛑 Robot movement stopped")
                self.cleanup_steps.append("Robot movement stopped")
            
            # Center head
            if hasattr(robot, 'head_velocity_manager') and robot.head_velocity_manager:
                for _ in range(3):
                    robot.head_velocity_manager.set_head_position(0.0)
                    time.sleep(0.2)
                
                print("🎯 Head centered")
                self.cleanup_steps.append("Head centered")
                
        except Exception as e:
            print(f"❌ Robot stop error: {e}")
            self.cleanup_steps.append(f"Robot stop error: {e}")
    
    def perform_complete_cleanup(self) -> bool:
        """Perform complete system cleanup for mode transition"""
        start_time = time.time()
        print("🧹 Starting complete LiDAR Chase cleanup...")
        
        success_count = 0
        total_steps = 7
        
        # Step 1: Stop robot movement
        self.stop_robot_movement()
        success_count += 1
        
        # Step 2: Stop WORKING LiDAR system with motor shutdown
        if self.stop_working_lidar_system():
            success_count += 1
        
        # Step 3: Additional robot sensor cleanup
        self.cleanup_robot_lidar_sensor()
        success_count += 1
        
        # Step 4: Restore display for IDLE mode (CRITICAL)
        if self.restore_display_for_idle_mode():
            success_count += 1
        
        # Step 5: Clean up pygame resources for mode transition
        if self.cleanup_pygame_resources():
            success_count += 1
        
        # Step 6: Clean up legacy systems
        if self.cleanup_legacy_systems():
            success_count += 1
        
        # Step 7: Final cleanup
        self.wait_for_background_threads()
        self.cleanup_blackboard()
        success_count += 1
        
        cleanup_time = time.time() - start_time
        success_rate = (success_count / total_steps) * 100
        
        print(f"✅ Cleanup completed: {success_count}/{total_steps} steps ({success_rate:.1f}%) in {cleanup_time:.2f}s")
        print("🎭 Ready for IDLE mode face avatar")
        
        return success_count >= (total_steps * 0.8)  # 80% success rate required
    
    def update(self) -> Status:
        """Execute FIXED cleanup for mode transition"""
        try:
            print("🔄 Executing LiDAR Chase mode exit cleanup...")
            
            # Perform complete cleanup
            cleanup_success = self.perform_complete_cleanup()
            
            if cleanup_success:
                print("✅ LiDAR Chase cleanup successful - mode transition ready")
                return Status.SUCCESS
            else:
                print("⚠️ Some cleanup issues occurred but allowing transition")
                return Status.SUCCESS  # Still allow behavior tree to continue
            
        except Exception as e:
            print(f"❌ Cleanup execution error: {e}")
            
            # Emergency cleanup - ensure robot stops and display is freed
            try:
                robot = self.get_robot()
                
                # Emergency stop
                if hasattr(robot, 'velocity_manager') and robot.velocity_manager:
                    from src.types.MovementDirection import MovementDirection
                    from src.action_managers.VelocityManager import VelocityConfig
                    stop_config = VelocityConfig(MovementDirection.NONE, 0.0)
                    robot.velocity_manager.perform_action(stop_config)
                
                # Emergency display clear
                if pygame.get_init():
                    screen = pygame.display.get_surface()
                    if screen:
                        screen.fill((0, 0, 0))
                        pygame.display.flip()
                    pygame.event.clear()
                
                print("🚨 Emergency cleanup executed")
                
            except Exception as emergency_error:
                print(f"❌ Emergency cleanup error: {emergency_error}")
            
            return Status.SUCCESS  # Don't block behavior tree
    
    def get_cleanup_status(self) -> dict:
        """Get detailed cleanup status"""
        return {
            "cleanup_steps_completed": len(self.cleanup_steps),
            "cleanup_steps": self.cleanup_steps.copy(),
            "pygame_initialized": pygame.get_init() if 'pygame' in globals() else False,
            "blackboard_systems": {
                "lidar_system": self.blackboard.exists("LIDAR_SYSTEM"),
                "lidar_renderer": self.blackboard.exists("LIDAR_RENDERER"),
            },
            "version": "FIXED for exclusive display mode with proper IDLE restoration"
        }


# Aliases for backward compatibility
CloseLidarPlot = FixedCloseLidarPlot
EnhancedCloseLidarPlot = FixedCloseLidarPlot