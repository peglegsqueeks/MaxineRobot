from enum import Enum


class DirectionSensorLocation(Enum):
    FRONT = "front"
    BACK = "back"
    LEFT = "left"
    RIGHT = "right"
