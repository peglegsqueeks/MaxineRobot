from typing import List, Tuple, Optional, Set
import heapq
import math
import numpy as np
from src.path_finding.Position import Position


# FIXED resolution for working with real LiDAR data
RESOLUTION = 80  # 8cm grid resolution - good balance for 10cm buffer
PAD_ROUNDS = 1   # Minimal padding for 10cm buffer

# Simplified movement directions for better performance
DIRECTIONS = [
    # Primary directions (high priority)
    (0, 1),   # Forward
    (1, 0),   # Right  
    (-1, 0),  # Left
    (0, -1),  # Backward
    
    # Diagonal directions for smoother paths
    (1, 1),   # Forward-right
    (-1, 1),  # Forward-left
    (1, -1),  # Backward-right
    (-1, -1), # Backward-left
    
    # Extended movements for efficiency
    (0, 2),   # Fast forward
    (1, 2),   # Fast forward-right
    (-1, 2),  # Fast forward-left
]


class FixedRobotAwareAStar:
    """
    FIXED A* pathfinding algorithm with 10cm buffer max as requested
    Works with real LiDAR data from working implementation
    """
    
    def __init__(self, robot_width=500, robot_length=650, safety_buffer=100):  # 100mm = 10cm
        self.robot_width = robot_width      # mm
        self.robot_length = robot_length    # mm  
        self.safety_buffer = safety_buffer  # 100mm = 10cm MAX as requested
        
        # Calculate total clearance needed (MINIMAL as requested)
        self.clearance_radius = (max(robot_width, robot_length) / 2) + safety_buffer  # ~425mm total
        
        # Grid parameters
        self.resolution = RESOLUTION  # 8cm grid
        self.max_grid_size = 120      # 120x120 grid (9.6m x 9.6m at 8cm resolution)
        
    def polar_to_cartesian(self, pos: Position) -> Tuple[float, float]:
        """Convert polar position to cartesian coordinates"""
        if pos.distance == 0:
            return (0.0, 0.0)
        
        x = pos.distance * math.cos(pos.angle)
        y = pos.distance * math.sin(pos.angle)
        return (x, y)
    
    def cartesian_to_polar(self, x: float, y: float) -> Position:
        """Convert cartesian coordinates to polar position"""
        distance = math.hypot(x, y)
        if distance == 0:
            return Position(distance=0.0, angle=0.0)
        
        angle = math.atan2(x, y)
        return Position(angle=angle, distance=distance)
    
    def position_to_grid(self, pos: Position) -> Tuple[int, int]:
        """Convert position to grid coordinates"""
        x, y = self.polar_to_cartesian(pos)
        grid_x = int((x + self.max_grid_size * self.resolution / 2) / self.resolution)
        grid_y = int((y + self.max_grid_size * self.resolution / 2) / self.resolution)
        
        # Clamp to grid bounds
        grid_x = max(0, min(self.max_grid_size - 1, grid_x))
        grid_y = max(0, min(self.max_grid_size - 1, grid_y))
        
        return (grid_x, grid_y)
    
    def grid_to_position(self, grid_x: int, grid_y: int) -> Position:
        """Convert grid coordinates to position"""
        x = (grid_x * self.resolution) - (self.max_grid_size * self.resolution / 2)
        y = (grid_y * self.resolution) - (self.max_grid_size * self.resolution / 2)
        return self.cartesian_to_polar(x, y)
    
    def add_minimal_clearance_to_obstacles(self, obstacles: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        """
        Add MINIMAL robot clearance (10cm buffer) around obstacles
        """
        if not obstacles:
            return []
        
        buffered = set(obstacles)  # Start with original obstacles
        clearance_cells = max(1, int(self.clearance_radius / self.resolution))  # Minimal cells for 10cm
        
        # MINIMAL clearance pattern - just essential cells for 10cm buffer
        clearance_pattern = []
        for dx in range(-clearance_cells, clearance_cells + 1):
            for dy in range(-clearance_cells, clearance_cells + 1):
                distance = math.sqrt(dx*dx + dy*dy) * self.resolution
                if distance <= self.clearance_radius:
                    clearance_pattern.append((dx, dy))
        
        # Apply MINIMAL clearance pattern
        for obs_x, obs_y in obstacles:
            for dx, dy in clearance_pattern:
                new_x = obs_x + dx
                new_y = obs_y + dy
                
                # Check bounds
                if (0 <= new_x < self.max_grid_size and 
                    0 <= new_y < self.max_grid_size):
                    buffered.add((new_x, new_y))
        
        return list(buffered)
    
    def preprocess_obstacles(self, obstacles: List[Position]) -> Set[Tuple[int, int]]:
        """
        Convert obstacles to grid with MINIMAL clearance for 10cm buffer
        """
        # Convert to grid coordinates
        grid_obstacles = []
        for obs in obstacles:
            # Filter reasonable obstacles for indoor navigation
            if 200 < obs.distance < 4000:  # 20cm to 4m range
                grid_pos = self.position_to_grid(obs)
                grid_obstacles.append(grid_pos)
        
        # Remove duplicates
        unique_obstacles = list(set(grid_obstacles))
        
        # Add MINIMAL robot clearance (10cm buffer)
        buffered_obstacles = self.add_minimal_clearance_to_obstacles(unique_obstacles)
        
        return set(buffered_obstacles)
    
    def heuristic(self, pos1: Tuple[int, int], pos2: Tuple[int, int]) -> float:
        """
        Simple Euclidean heuristic for better performance
        """
        dx = abs(pos1[0] - pos2[0])
        dy = abs(pos1[1] - pos2[1])
        
        # Simple Euclidean distance
        return math.sqrt(dx*dx + dy*dy)
    
    def get_movement_cost(self, current: Tuple[int, int], neighbor: Tuple[int, int]) -> float:
        """
        Simple movement cost calculation
        """
        dx = abs(neighbor[0] - current[0])
        dy = abs(neighbor[1] - current[1])
        
        # Base movement cost
        if dx == 0 or dy == 0:
            # Straight movement (preferred)
            base_cost = max(dx, dy)
        else:
            # Diagonal movement
            base_cost = math.sqrt(dx*dx + dy*dy)
        
        # Small penalty for larger steps
        if dx > 1 or dy > 1:
            base_cost *= 1.1
        
        return base_cost
    
    def is_valid_position(self, pos: Tuple[int, int], obstacles: Set[Tuple[int, int]]) -> bool:
        """Check if position is valid"""
        x, y = pos
        return (0 <= x < self.max_grid_size and 
                0 <= y < self.max_grid_size and 
                pos not in obstacles)
    
    def get_neighbors(self, current: Tuple[int, int]) -> List[Tuple[int, int]]:
        """Get valid neighbor positions"""
        neighbors = []
        
        for dx, dy in DIRECTIONS:
            neighbor = (current[0] + dx, current[1] + dy)
            
            # Basic bounds check
            if (0 <= neighbor[0] < self.max_grid_size and 
                0 <= neighbor[1] < self.max_grid_size):
                neighbors.append(neighbor)
        
        return neighbors
    
    def reconstruct_path(self, came_from: dict, current: Tuple[int, int], 
                        start: Tuple[int, int]) -> List[Position]:
        """Reconstruct path and convert to Position objects"""
        path = []
        
        while current in came_from:
            position = self.grid_to_position(current[0], current[1])
            path.append(position)
            current = came_from[current]
        
        # Add start position
        start_position = self.grid_to_position(start[0], start[1])
        path.append(start_position)
        
        # Reverse to get path from start to goal
        path.reverse()
        
        return path
    
    def find_path(self, obstacles: List[Position], goal: Position) -> Tuple[List[Position], dict]:
        """
        FIXED A* pathfinding algorithm with 10cm buffer
        """
        try:
            # Preprocess obstacles with MINIMAL clearance (10cm buffer)
            obstacle_set = self.preprocess_obstacles(obstacles)
            
            # Convert start and goal to grid coordinates
            start = (self.max_grid_size // 2, self.max_grid_size // 2)  # Robot starts at center
            goal_grid = self.position_to_grid(goal)
            
            # Check if goal is reachable
            if not self.is_valid_position(goal_grid, obstacle_set):
                # Try to find nearest valid goal
                goal_grid = self.find_nearest_valid_position(goal_grid, obstacle_set)
                if not goal_grid:
                    return [], {"error": "Goal unreachable"}
            
            # A* algorithm
            open_set = [(0, start)]
            came_from = {}
            g_score = {start: 0}
            f_score = {start: self.heuristic(start, goal_grid)}
            closed_set = set()
            
            nodes_explored = 0
            max_nodes = 3000  # Reduced for better performance
            
            while open_set and nodes_explored < max_nodes:
                current = heapq.heappop(open_set)[1]
                nodes_explored += 1
                
                if current in closed_set:
                    continue
                
                closed_set.add(current)
                
                # Check if goal reached
                if current == goal_grid:
                    path = self.reconstruct_path(came_from, current, start)
                    
                    debug_info = {
                        "nodes_explored": nodes_explored,
                        "path_length": len(path),
                        "obstacles_processed": len(obstacle_set),
                        "goal_grid": goal_grid,
                        "clearance_radius": f"{self.clearance_radius:.0f}mm (10cm buffer)",
                        "grid_resolution": f"{self.resolution}mm"
                    }
                    
                    return path, debug_info
                
                # Explore neighbors
                for neighbor in self.get_neighbors(current):
                    if neighbor in closed_set or not self.is_valid_position(neighbor, obstacle_set):
                        continue
                    
                    tentative_g_score = g_score[current] + self.get_movement_cost(current, neighbor)
                    
                    if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                        came_from[neighbor] = current
                        g_score[neighbor] = tentative_g_score
                        f_score[neighbor] = tentative_g_score + self.heuristic(neighbor, goal_grid)
                        
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))
            
            # No path found
            return [], {
                "error": "No path found",
                "nodes_explored": nodes_explored,
                "obstacles_processed": len(obstacle_set),
                "clearance_radius": f"{self.clearance_radius:.0f}mm (10cm buffer)"
            }
            
        except Exception as e:
            return [], {"error": f"A* algorithm error: {str(e)}"}
    
    def find_nearest_valid_position(self, goal: Tuple[int, int], 
                                   obstacles: Set[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
        """
        Find nearest valid position to an unreachable goal
        """
        for radius in range(1, 15):  # Search up to 15 cells away
            for dx in range(-radius, radius + 1):
                for dy in range(-radius, radius + 1):
                    if abs(dx) == radius or abs(dy) == radius:  # Only check perimeter
                        candidate = (goal[0] + dx, goal[1] + dy)
                        if self.is_valid_position(candidate, obstacles):
                            return candidate
        return None


# Global instance configured for 10cm buffer
_fixed_robot_astar = FixedRobotAwareAStar(robot_width=500, robot_length=650, safety_buffer=100)


def a_star(obstacles: List[Position], goal: Position) -> Tuple[List[Position], dict]:
    """
    FIXED A* pathfinding function with 10cm buffer MAX as requested
    
    Args:
        obstacles: List of obstacle positions in polar coordinates
        goal: Target position in polar coordinates
        
    Returns:
        Tuple of (path_positions, debug_info)
    """
    return _fixed_robot_astar.find_path(obstacles, goal)


def configure_robot_dimensions(width: float, length: float, safety_buffer: float = 100.0):
    """
    Configure robot dimensions for pathfinding
    
    Args:
        width: Robot width in mm
        length: Robot length in mm  
        safety_buffer: Safety margin in mm (DEFAULT 10cm as requested)
    """
    global _fixed_robot_astar
    _fixed_robot_astar = FixedRobotAwareAStar(width, length, safety_buffer)


def get_pathfinding_status() -> dict:
    """Get current pathfinding configuration status"""
    return {
        "robot_width": _fixed_robot_astar.robot_width,
        "robot_length": _fixed_robot_astar.robot_length,
        "safety_buffer": f"{_fixed_robot_astar.safety_buffer}mm (10cm MAX as requested)",
        "clearance_radius": f"{_fixed_robot_astar.clearance_radius:.0f}mm",
        "grid_resolution": f"{_fixed_robot_astar.resolution}mm (8cm)",
        "max_grid_size": _fixed_robot_astar.max_grid_size,
        "version": "FIXED for 10cm buffer and real LiDAR data"
    }


# Test function to verify 10cm buffer
def test_pathfinding_with_minimal_buffer(obstacles: List[Position], goal: Position) -> dict:
    """
    Test pathfinding with 10cm buffer and real LiDAR data
    """
    import time
    
    start_time = time.time()
    path, debug_info = a_star(obstacles, goal)
    calculation_time = time.time() - start_time
    
    return {
        "path": path,
        "path_length": len(path),
        "calculation_time": calculation_time,
        "success": len(path) > 0,
        "debug_info": debug_info,
        "pathfinding_config": get_pathfinding_status(),
        "buffer_verification": "10cm MAX buffer as requested"
    }


# Initialize with 10cm buffer as requested