from typing import Dict
from depthai import Pipeline
import depthai as dai
from depthai import MonoCameraProperties, ColorCameraProperties
from abc import ABC, abstractmethod


class DepthAiPipeline(ABC):
    """
    Base class for all DepthAI Pipelines
    Children must implement the configure() method, which configures the pipeline
    This class contains helper methods to create various depth ai nodes
    """

    def __init__(self) -> None:
        """
        Initiliases the pipeline
        Will call configure() which will build the pipeline
        """
        self.pipeline = None
        self.pipeline = Pipeline()
        self.configure()

    @abstractmethod
    def configure(self):
        """
        Configures the pipeline
        All children must implement this method
        """
        pass

    @abstractmethod
    def get_output_queues(self, device: dai.Device) -> Dict[str, dai.DataOutputQueue]:
        """
        Returns a dictionary of output queues that represent the predictions from the pipeline
        all children must implement this

        arguments:
            - device: the current dai device
        """
        pass

    def make_mono_camera(self, name: str) -> dai.node.MonoCamera:
        """
        Builds a mono camera with maximum wide angle FOV for IMX378/214 sensor
        """
        camera = self.pipeline.create(dai.node.MonoCamera)
        
        # Use THE_800_P for maximum wide angle FOV as requested
        camera.setResolution(MonoCameraProperties.SensorResolution.THE_800_P)
        camera.setFps(30)  # Stable FPS for good performance
        camera.setCamera(name)
        
        # Enable maximum wide-angle FOV settings
        # These settings help maximize the field of view
        camera.initialControl.setManualFocus(130)  # Set to infinity focus for wide view
        
        print(f"✅ Mono camera '{name}' configured with THE_800_P resolution for maximum wide FOV")
        
        return camera

    def make_color_camera(self) -> dai.node.ColorCamera:
        """
        Builds a colour camera with IMX378/214 compatible resolution
        """
        camera = self.pipeline.create(dai.node.ColorCamera)
        # Use 1080P which is explicitly supported by IMX378/214
        camera.setResolution(ColorCameraProperties.SensorResolution.THE_1080_P)
        camera.setInterleaved(False)
        camera.setBoardSocket(dai.CameraBoardSocket.RGB)
        camera.setFps(20)  # Add FPS setting for consistency

        return camera

    def make_stereo_sensor(self) -> dai.node.StereoDepth:
        """
        Builds a stereo sensor optimized for wide-angle mono cameras and depth perception
        """
        stereo = self.pipeline.create(dai.node.StereoDepth)
        
        # Optimize for wide-angle stereo vision
        stereo.setDefaultProfilePreset(dai.node.StereoDepth.PresetMode.HIGH_ACCURACY)
        stereo.initialConfig.setConfidenceThreshold(230)  # Good confidence for accurate depth
        
        # Enable features for better depth perception
        stereo.setSubpixel(True)  # Enable for better depth accuracy
        stereo.setLeftRightCheck(True)  # Enable for better depth quality
        stereo.setExtendedDisparity(False)  # Keep false for wide-angle stability
        
        # Optimize depth range for person detection (0.3m to 10m)
        stereo.initialConfig.setBilateralFilterSigma(0)  # Disable bilateral filter for speed
        stereo.setDepthAlign(dai.CameraBoardSocket.RIGHT)  # Align depth to RIGHT mono camera
        
        # Set median filter for noise reduction
        stereo.initialConfig.setMedianFilter(dai.MedianFilter.KERNEL_7x7)
        
        print("✅ Stereo sensor configured for optimal wide-angle depth perception")
        
        return stereo

    def make_image_manip(
        self, resize_dim: int, keep_aspect: bool
    ) -> dai.node.ImageManip:
        """
        Builds an ImageManip node

        arguments:
            - resize_dim: the dimension to resize to
            - keep_aspect: wether to keep the aspect ratio or not
        """
        manip = self.pipeline.create(dai.node.ImageManip)
        manip.initialConfig.setResize(resize_dim, resize_dim)
        manip.initialConfig.setFrameType(dai.RawImgFrame.Type.RGB888p)
        manip.setKeepAspectRatio(keep_aspect)
        
        # Add max frame pool size to prevent memory issues
        manip.setMaxOutputFrameSize(resize_dim * resize_dim * 3)

        return manip

    def make_net(
        self,
        network: type[dai.node.DetectionNetwork],
        blob_path: str,
        threshold: float,
        queue_size: int,
        blocking: bool,
    ) -> dai.node.DetectionNetwork:
        """
        Builds a depth ai NN with error handling

        arguments:
            - network: the type of NN to build
            - blob_path: the path of the NN weights
            - threshold: the threshold for detection
            - queue_size: the size of the queue
            - blocking: wether acessing the queue is blocking
        """
        try:
            net = self.pipeline.create(network)
            net.setConfidenceThreshold(threshold)
            net.setBlobPath(blob_path)
            net.input.setQueueSize(queue_size)
            net.input.setBlocking(blocking)
            
            print(f"✅ Neural network created: {blob_path} (threshold: {threshold})")
            return net
            
        except Exception as e:
            print(f"❌ Error creating neural network: {e}")
            raise

    def make_output(self, node_output: dai.Node.Output, name: str) -> dai.node.XLinkOut:
        """
        Builds a XLinkOut node and links a previous output to its input

        arguments:
            - node_output: the previous layer to link the input to
            - name: the name of the output
        """
        output = self.pipeline.create(dai.node.XLinkOut)
        output.setStreamName(name)

        node_output.link(output.input)

        return output