import pygame
import time
import math
import numpy as np
import threading
import queue
import signal
import sys
from math import radians
from src.path_finding.Position import Position
from pyrplidar import PyRPlidar

from src.behaviors.MaxineBehavior import MaxineBehavior
from py_trees.common import Status
import depthai as dai
import py_trees


class BalancedPerformancePyRPLidarA3:
    """WORKING LiDAR implementation - copied from working-optimised-lidar2.py"""
    
    def __init__(self, port='/dev/ttyUSB0', baudrate=256000, timeout=1.5):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.lidar = None
        self.is_connected = False
        self.scan_generator = None
        self.scan_iterator = None
        
        # A3 Balanced Performance Parameters - EXACTLY from working version
        self.motor_pwm = 650      # Slightly reduced for stability
        self.scan_mode = 2        # Mode 2 for optimal A3 performance

    def connect(self):
        """Connect to the LiDAR device"""
        try:
            self.lidar = PyRPlidar()
            self.lidar.connect(port=self.port, baudrate=self.baudrate, timeout=self.timeout)
            self.is_connected = True
            return True
        except Exception as e:
            self.is_connected = False
            return False

    def disconnect(self):
        """Disconnect from the LiDAR device"""
        try:
            if self.lidar and self.is_connected:
                self.lidar.stop()
                self.lidar.set_motor_pwm(0)  # CRITICAL: Stop motor
                self.lidar.disconnect()
                self.is_connected = False
        except Exception as e:
            pass

    def start_scanning(self, mode='high_performance'):
        """Start scanning using high-performance settings"""
        try:
            if not self.is_connected:
                return False
                
            self.lidar.stop()
            self.lidar.set_motor_pwm(self.motor_pwm)
            time.sleep(2)  # Proper stabilization time
            
            if mode == 'high_performance':
                self.scan_generator = self.lidar.start_scan_express(self.scan_mode)
                self.scan_iterator = self.scan_generator()
                return True
            elif mode == 'stability':
                self.scan_generator = self.lidar.start_scan_express(1)
                self.scan_iterator = self.scan_generator()
                return True
            elif mode == 'force':
                self.scan_generator = self.lidar.force_scan()
                self.scan_iterator = self.scan_generator()
                return True
            
            return True
            
        except Exception as e:
            return False

    def get_scan_data_generator(self, shutdown_flag):
        """WORKING generator - copied exactly from working version"""
        if not self.is_connected or not self.lidar or not self.scan_iterator:
            return
            
        consecutive_failures = 0
        max_failures = 50
        scan_buffer = []
        last_angle = None
        min_scan_points = 200
        restart_count = 0
        max_restarts = 3
        
        while consecutive_failures < max_failures:
            if shutdown_flag[0]:
                break
                
            try:
                measurement = next(self.scan_iterator)
                
                if measurement:
                    consecutive_failures = 0
                    
                    try:
                        quality = getattr(measurement, 'quality', 0)
                        angle = getattr(measurement, 'angle', 0)
                        distance = getattr(measurement, 'distance', 0)
                        
                        if quality > 0 and distance > 0 and distance < 8000:
                            scan_buffer.append((quality, angle, distance))
                            
                            if last_angle is not None and angle < last_angle and len(scan_buffer) > min_scan_points:
                                yield scan_buffer.copy()
                                scan_buffer.clear()
                            
                            last_angle = angle
                        
                    except Exception as measurement_error:
                        continue
                else:
                    consecutive_failures += 1
                    time.sleep(0.01)
                    
            except StopIteration:
                restart_count += 1
                if restart_count >= max_restarts:
                    break
                
                time.sleep(1)
                
                if self.start_scanning('high_performance'):
                    consecutive_failures = 0
                    scan_buffer.clear()
                    last_angle = None
                    continue
                elif self.start_scanning('stability'):
                    consecutive_failures = 0
                    scan_buffer.clear()
                    last_angle = None
                    continue
                else:
                    break
            except Exception as e:
                consecutive_failures += 1
                time.sleep(0.1)


class WorkingLidarSystem:
    """WORKING LiDAR system - based on working-optimised-lidar2.py"""
    
    def __init__(self, port='/dev/ttyUSB0', baudrate=256000):
        self.port = port
        self.baudrate = baudrate
        self.lidar = None
        
        # High-performance data structures - EXACTLY from working version
        self.scan_queue = queue.Queue(maxsize=1)  # Minimal queue for lowest latency
        self.latest_obstacles = []
        self.data_lock = threading.Lock()
        
        # WORKING obstacle mapping parameters
        self.obstacle_confidence = {}
        self.scan_cycle_count = 0
        self.angle_resolution = 0.5    # Fine resolution - FROM WORKING VERSION
        self.distance_resolution = 20  # Very fine distance resolution - FROM WORKING VERSION
        
        # WORKING decay parameters
        self.confidence_threshold = 0.2    # Balanced threshold - FROM WORKING VERSION
        self.confidence_increment = 0.3    # Faster confidence building - FROM WORKING VERSION
        self.confidence_decay = 0.08       # Moderate decay - FROM WORKING VERSION
        self.max_confidence = 1.0
        
        # Performance monitoring
        self.scan_rate = 0
        self.last_scan_time = time.time()
        self.scan_count = 0
        self.processing_time = 0
        
        # Control flags
        self.running = False
        self.shutdown_flag = [False]
        self.threads = []
        
    def data_acquisition_thread(self):
        """WORKING data acquisition - copied from working version"""
        try:
            self.lidar = BalancedPerformancePyRPLidarA3(self.port, self.baudrate, timeout=1.5)
            
            if not self.lidar.connect():
                return
            
            if not self.lidar.start_scanning('high_performance'):
                if not self.lidar.start_scanning('stability'):
                    if not self.lidar.start_scanning('force'):
                        return
            
            try:
                for scan_data in self.lidar.get_scan_data_generator(self.shutdown_flag):
                    if not self.running or self.shutdown_flag[0]:
                        break
                    
                    start_time = time.time()
                    
                    try:
                        if scan_data and len(scan_data) > 0:
                            # Performance monitoring
                            self.scan_count += 1
                            current_time = time.time()
                            if current_time - self.last_scan_time >= 10.0:  # Report every 10 seconds
                                self.scan_rate = self.scan_count / (current_time - self.last_scan_time)
                                self.scan_count = 0
                                self.last_scan_time = current_time
                                self.processing_time = 0
                            
                            # WORKING obstacle confidence update
                            self.update_obstacle_confidence_fast(scan_data)
                            
                            # Get confident obstacles
                            stable_obstacles = self.get_confident_obstacles()
                            
                            if len(stable_obstacles) > 0:
                                with self.data_lock:
                                    self.latest_obstacles = stable_obstacles
                                
                                # Non-blocking queue update
                                try:
                                    if not self.scan_queue.empty():
                                        self.scan_queue.get_nowait()
                                    self.scan_queue.put_nowait(stable_obstacles)
                                except (queue.Full, queue.Empty):
                                    pass
                            
                            # Track processing time
                            self.processing_time += time.time() - start_time
                        
                    except Exception as e:
                        if not self.shutdown_flag[0]:
                            pass
                        continue
                        
            except Exception as loop_error:
                pass
                
        except Exception as e:
            pass
        finally:
            if self.lidar:
                self.lidar.disconnect()
    
    def update_obstacle_confidence_fast(self, scan_data):
        """WORKING confidence update - copied exactly from working version"""
        self.scan_cycle_count += 1
        
        # Pre-allocate set for performance
        seen_obstacles = set()
        
        # Fast processing of scan data - EXACTLY from working version
        for quality, angle, distance in scan_data:
            if distance > 50 and quality > 0 and distance < 4000:  # Filter very close noise
                # Normalize angle
                normalized_angle = ((angle + 180) % 360) - 180
                
                # Bin coordinates
                angle_bin = round(normalized_angle / self.angle_resolution) * self.angle_resolution
                distance_bin = round(distance / self.distance_resolution) * self.distance_resolution
                
                key = (angle_bin, distance_bin)
                seen_obstacles.add(key)
                
                # Fast confidence update
                current_confidence = self.obstacle_confidence.get(key, 0)
                self.obstacle_confidence[key] = min(
                    self.max_confidence, 
                    current_confidence + self.confidence_increment
                )
        
        # Aggressive decay for unseen obstacles
        obstacles_to_remove = []
        for key, confidence in list(self.obstacle_confidence.items()):
            if key not in seen_obstacles:
                new_confidence = confidence - self.confidence_decay
                if new_confidence <= 0:
                    obstacles_to_remove.append(key)
                else:
                    self.obstacle_confidence[key] = new_confidence
        
        # Batch remove low-confidence obstacles
        for key in obstacles_to_remove:
            del self.obstacle_confidence[key]
    
    def get_confident_obstacles(self):
        """WORKING obstacle retrieval"""
        return [(angle, distance) for (angle, distance), confidence 
                in self.obstacle_confidence.items() 
                if confidence >= self.confidence_threshold]
    
    def get_latest_obstacles(self):
        """Get latest obstacles for external use"""
        try:
            return self.scan_queue.get_nowait()
        except queue.Empty:
            return None
    
    def start(self):
        """Start the WORKING LiDAR system"""
        self.running = True
        self.shutdown_flag[0] = False
        
        # High-priority thread
        data_thread = threading.Thread(target=self.data_acquisition_thread, daemon=True)
        data_thread.start()
        self.threads.append(data_thread)
        
        return True
    
    def stop(self):
        """Stop the system properly"""
        self.running = False
        self.shutdown_flag[0] = True
        
        for thread in self.threads:
            thread.join(timeout=2.0)
        
        if self.lidar:
            self.lidar.disconnect()


class ExclusivePygameLidarRenderer:
    """WORKING pygame renderer using LidarTestBehavior approach"""
    
    def __init__(self):
        # WORKING screen setup from LidarTestBehavior.py
        print("🖥️ Setting up exclusive pygame display using working approach...")
        
        # Get display info for fullscreen
        display_info = pygame.display.Info()
        self.screen_width = display_info.current_w
        self.screen_height = display_info.current_h
        self.center_x = self.screen_width // 2
        self.center_y = self.screen_height // 2
        
        # CREATE FULLSCREEN SURFACE - using working approach
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height), pygame.FULLSCREEN)
        pygame.display.set_caption("MAXINE LIDAR CHASE - WORKING DISPLAY")
        
        self.display_owned = True
        
        # Calculate display scale based on screen size (from working code)
        self.display_scale = min(self.screen_width, self.screen_height) // 20
        self.max_display_range = 8  # 8 meters
        self.max_distance = 4000  # For internal calculations
        self.max_radius = min(self.screen_width, self.screen_height) // 2 - 80
        
        # Colors (from working LidarTestBehavior)
        self.colors = {
            'background': (0, 0, 0),
            'grid': (0, 100, 0),
            'distance_rings': (0, 150, 0),
            'angle_marks': (0, 200, 0),
            'obstacles': (255, 0, 0),
            'robot': (0, 0, 255),
            'target': (255, 255, 0),
            'safe_path': (0, 255, 255),
            'text': (255, 255, 255),
            'status_good': (0, 255, 0),
            'status_warning': (255, 255, 0),
            'status_danger': (255, 0, 0),
            'path_color': (255, 255, 0),        # YELLOW for path
            'waypoint_color': (255, 255, 255)   # WHITE for waypoints
        }
        
        # Fonts
        self.font = pygame.font.Font(None, 48)
        self.small_font = pygame.font.Font(None, 36)
        self.info_font = pygame.font.Font(None, 40)
        
        # Obstacle persistence
        self.obstacle_persistence = {}
        self.max_persistence = 1.0
        self.persistence_decay = 0.05
        self.persistence_increment = 0.8
        
        print(f"✅ Working display setup complete: {self.screen_width}x{self.screen_height}")
    
    def draw_distance_rings(self, screen):
        """Draw distance rings and grid - from working LidarTestBehavior"""
        # Distance rings at 1m, 2m, 4m, 6m, 8m
        for distance in [1, 2, 4, 6, 8]:
            radius = distance * self.display_scale
            max_radius = min(self.center_x, self.center_y) - 50
            if radius < max_radius:
                pygame.draw.circle(screen, self.colors['distance_rings'], 
                                 (self.center_x, self.center_y), radius, 2)
                
                # Distance labels
                text = self.small_font.render(f"{distance}m", True, self.colors['distance_rings'])
                screen.blit(text, (self.center_x + radius - 30, self.center_y - 15))

    def draw_angle_markings(self, screen):
        """Draw angle markings - from working LidarTestBehavior"""
        max_radius = min(self.center_x, self.center_y) - 100
        
        for angle in range(0, 360, 30):
            # Convert to display coordinates
            display_angle_rad = math.radians(90 - angle)
            
            # Calculate line endpoints
            start_x = self.center_x + int((max_radius - 30) * math.cos(display_angle_rad))
            start_y = self.center_y - int((max_radius - 30) * math.sin(display_angle_rad))
            end_x = self.center_x + int(max_radius * math.cos(display_angle_rad))
            end_y = self.center_y - int(max_radius * math.sin(display_angle_rad))
            
            # Draw angle line
            line_width = 3 if angle % 90 == 0 else 2
            pygame.draw.line(screen, self.colors['angle_marks'], 
                           (start_x, start_y), (end_x, end_y), line_width)
            
            # Angle labels
            text_x = self.center_x + int((max_radius + 40) * math.cos(display_angle_rad))
            text_y = self.center_y - int((max_radius + 40) * math.sin(display_angle_rad))
            
            text = self.small_font.render(f"{angle}°", True, self.colors['angle_marks'])
            text_rect = text.get_rect(center=(text_x, text_y))
            screen.blit(text, text_rect)

    def draw_robot(self, screen):
        """Draw robot at center - from working LidarTestBehavior"""
        # Robot body
        pygame.draw.circle(screen, self.colors['robot'], 
                         (self.center_x, self.center_y), 15, 4)
        
        # Robot direction arrow (pointing up = 0° forward)
        arrow_length = 25
        end_x = self.center_x
        end_y = self.center_y - arrow_length
        pygame.draw.line(screen, self.colors['robot'], 
                       (self.center_x, self.center_y), (end_x, end_y), 6)
        
        # Add 0° direction label
        text = self.small_font.render("0°", True, self.colors['robot'])
        screen.blit(text, (self.center_x - 10, self.center_y - arrow_length - 25))

    def draw_obstacles_working(self, screen, obstacles):
        """Draw obstacles using working approach from LidarTestBehavior"""
        if not obstacles:
            # Show "no obstacles" status
            status_text = self.info_font.render("LiDAR: No obstacles detected", True, self.colors['status_warning'])
            screen.blit(status_text, (self.screen_width - 400, 200))
            return
            
        drawn_obstacles = 0
        
        for angle, distance in obstacles:
            try:
                # Convert to display coordinates using working method
                distance_m = distance / 1000.0  # Convert mm to meters
                
                if 0.1 <= distance_m <= self.max_display_range:
                    # Working coordinate transformation from LidarTestBehavior
                    display_angle_rad = math.radians(90 - angle)
                    
                    x = self.center_x + int(distance_m * self.display_scale * math.cos(display_angle_rad))
                    y = self.center_y - int(distance_m * self.display_scale * math.sin(display_angle_rad))
                    
                    # Ensure point is within screen bounds
                    if (50 <= x < self.screen_width - 50 and 50 <= y < self.screen_height - 50):
                        # Draw obstacle point (larger and more visible)
                        pygame.draw.circle(screen, self.colors['obstacles'], (x, y), 6)
                        drawn_obstacles += 1
                        
            except Exception as e:
                continue
        
        # Status text - show active obstacle count
        if drawn_obstacles > 0:
            status_text = self.info_font.render(f"LiDAR: {drawn_obstacles} obstacles active", True, self.colors['status_good'])
            screen.blit(status_text, (self.screen_width - 400, 200))
        else:
            status_text = self.info_font.render("LiDAR: Processing data...", True, self.colors['status_warning'])
            screen.blit(status_text, (self.screen_width - 400, 200))

    def position_to_screen_coords(self, position):
        """Convert position to screen coordinates using working method"""
        if not position or position.distance <= 0:
            return None
            
        # Convert to working coordinate system from LidarTestBehavior
        distance_m = position.distance / 1000.0  # Convert mm to meters
        
        if distance_m > self.max_display_range:
            return None
            
        angle_deg = math.degrees(position.angle)
        # Working coordinate transformation
        display_angle_rad = math.radians(90 - angle_deg)
        
        x = self.center_x + int(distance_m * self.display_scale * math.cos(display_angle_rad))
        y = self.center_y - int(distance_m * self.display_scale * math.sin(display_angle_rad))
        
        return (x, y)

    def draw_path_with_waypoints(self, screen, path):
        """Draw YELLOW path with WHITE waypoint circles"""
        if not path or len(path) < 1:
            return
            
        screen_points = []
        
        # Convert all path points to screen coordinates
        for position in path:
            screen_coord = self.position_to_screen_coords(position)
            if screen_coord:
                screen_points.append(screen_coord)
        
        if len(screen_points) >= 1:
            try:
                # Draw YELLOW path lines
                if len(screen_points) >= 2:
                    for i in range(len(screen_points) - 1):
                        pygame.draw.line(screen, self.colors['path_color'], 
                                       screen_points[i], screen_points[i + 1], 4)
                
                # Draw WHITE circles for waypoints
                for i, point in enumerate(screen_points):
                    if i == 0:
                        # First waypoint - larger white circle with green center
                        pygame.draw.circle(screen, self.colors['waypoint_color'], point, 12)
                        pygame.draw.circle(screen, (0, 255, 0), point, 6)
                    elif i == len(screen_points) - 1:
                        # Last waypoint - larger white circle with red center
                        pygame.draw.circle(screen, self.colors['waypoint_color'], point, 12)
                        pygame.draw.circle(screen, (255, 0, 0), point, 6)
                    else:
                        # Intermediate waypoints - WHITE circles
                        pygame.draw.circle(screen, self.colors['waypoint_color'], point, 8)
                        pygame.draw.circle(screen, self.colors['path_color'], point, 4)
                        
            except Exception as e:
                pass

    def draw_person_star(self, screen, center, size, color):
        """Draw star for person detection"""
        try:
            x, y = center
            points = []
            
            for i in range(10):
                angle = math.radians(i * 36 - 90)
                if i % 2 == 0:
                    radius = size
                else:
                    radius = size * 0.4
                
                point_x = x + radius * math.cos(angle)
                point_y = y + radius * math.sin(angle)
                points.append((int(point_x), int(point_y)))
            
            if len(points) >= 3:
                pygame.draw.polygon(screen, color, points)
                pygame.draw.polygon(screen, (255, 255, 255), points, 2)
        except Exception:
            # Fallback to circle
            pygame.draw.circle(screen, color, center, size//2)

    def render_frame(self, obstacles, target_position=None, path=None, lidar_system=None):
        """WORKING render frame using LidarTestBehavior approach"""
        try:
            # Clear screen with background color - WORKING METHOD
            self.screen.fill(self.colors['background'])
            
            # Draw static elements - WORKING METHOD
            self.draw_distance_rings(self.screen)
            self.draw_angle_markings(self.screen)
            self.draw_robot(self.screen)
            
            # Draw obstacles using working method
            self.draw_obstacles_working(self.screen, obstacles)
            
            # Draw YELLOW path with WHITE waypoints
            if path:
                self.draw_path_with_waypoints(self.screen, path)
            
            # Draw person detection
            if target_position:
                screen_coord = self.position_to_screen_coords(target_position)
                if screen_coord:
                    self.draw_person_star(self.screen, screen_coord, 20, self.colors['target'])
            
            # Draw title and status
            title = self.font.render("MAXINE LIDAR CHASE - WORKING DISPLAY", True, self.colors['text'])
            title_rect = title.get_rect(center=(self.screen_width // 2, 40))
            self.screen.blit(title, title_rect)
            
            # Exit instruction - ESC key works again
            exit_text = self.info_font.render("Press ESC to exit", True, self.colors['status_warning'])
            exit_rect = exit_text.get_rect(center=(self.screen_width // 2, 80))
            self.screen.blit(exit_text, exit_rect)
            
            # Show LiDAR system status
            if lidar_system and lidar_system.running:
                lidar_status_text = self.info_font.render("LiDAR System: ACTIVE", True, self.colors['status_good'])
                self.screen.blit(lidar_status_text, (self.screen_width - 400, 120))
            else:
                lidar_status_text = self.info_font.render("LiDAR System: STARTING...", True, self.colors['status_warning'])
                self.screen.blit(lidar_status_text, (self.screen_width - 400, 120))
            
            # Target info
            if target_position:
                info_x = self.screen_width - 300
                y_offset = 250
                
                target_text = self.info_font.render(f"Target: {math.degrees(target_position.angle):.1f}°", True, self.colors['text'])
                self.screen.blit(target_text, (info_x, y_offset))
                y_offset += 40
                
                dist_text = self.info_font.render(f"Distance: {target_position.distance:.0f}mm", True, self.colors['text'])
                self.screen.blit(dist_text, (info_x, y_offset))
                y_offset += 50
                
                # Path info
                if path and len(path) > 0:
                    path_text = self.info_font.render(f"Path: {len(path)} waypoints", True, self.colors['status_good'])
                    self.screen.blit(path_text, (info_x, y_offset))
                else:
                    no_path_text = self.info_font.render("Path: CALCULATING", True, self.colors['status_warning'])
                    self.screen.blit(no_path_text, (info_x, y_offset))
            else:
                # Show path info even without target
                info_x = self.screen_width - 300
                y_offset = 250
                if path and len(path) > 0:
                    path_text = self.info_font.render(f"Path: {len(path)} waypoints", True, self.colors['status_good'])
                    self.screen.blit(path_text, (info_x, y_offset))
                else:
                    no_path_text = self.info_font.render("Path: CALCULATING", True, self.colors['status_warning'])
                    self.screen.blit(no_path_text, (info_x, y_offset))
            
            # WORKING DISPLAY UPDATE - single flip
            pygame.display.flip()
                
        except Exception as e:
            print(f"❌ Render error: {e}")

    def release_display(self):
        """Release exclusive display control"""
        try:
            if self.display_owned:
                print("🖥️ Releasing exclusive display control...")
                # Fill screen black before releasing
                self.screen.fill((0, 0, 0))
                pygame.display.flip()
                self.display_owned = False
                print("✅ Display control released")
        except Exception as e:
            print(f"❌ Error releasing display: {e}")


class UpdateLidarPlot(MaxineBehavior):
    """WORKING LiDAR plot using LidarTestBehavior display approach - no blank screen"""
    
    def __init__(self):
        super().__init__("WORKING LiDAR Plot - LidarTestBehavior Display")

        self.blackboard.register_key("TARGET_PERSON", access=py_trees.common.Access.WRITE)
        self.blackboard.register_key("PATH", access=py_trees.common.Access.WRITE)
        self.blackboard.register_key("LIDAR_SYSTEM", access=py_trees.common.Access.WRITE)
        self.blackboard.register_key("LIDAR_RENDERER", access=py_trees.common.Access.WRITE)
        
        self.update_count = 0  # Initialize first
        self.lidar_init_attempts = 0
        self.max_init_attempts = 5  # Increased from 2 to 5 for better reliability
        self.last_status_print = 0
        self.status_print_interval = 10.0
        
        # Ensure pygame is initialized
        if not pygame.get_init():
            pygame.init()
            print("🎮 Pygame initialized using WORKING LidarTestBehavior approach")

    def get_or_create_lidar_system(self):
        """Get WORKING LiDAR system and keep it alive"""
        if self.blackboard.exists("LIDAR_SYSTEM"):
            lidar_system = self.blackboard.get("LIDAR_SYSTEM")
            if lidar_system and lidar_system.running:
                return lidar_system
            elif lidar_system and not lidar_system.running:
                # System exists but not running - try to restart it
                print("🔄 Restarting stopped LiDAR system...")
                if lidar_system.start():
                    time.sleep(2)  # Give time to stabilize
                    return lidar_system
                else:
                    # Failed to restart, clean up and try fresh
                    self.blackboard.unset("LIDAR_SYSTEM")
            else:
                # System exists but invalid, clean up
                self.blackboard.unset("LIDAR_SYSTEM")

        if self.lidar_init_attempts >= self.max_init_attempts:
            if self.update_count % 200 == 0:  # Print every 200 updates (less spam)
                print(f"❌ Max LiDAR init attempts ({self.max_init_attempts}) reached")
            return None

        # Add delay between attempts to avoid hammering the hardware
        if self.lidar_init_attempts > 0:
            time.sleep(0.5)  # Small delay between retries

        print(f"🚀 Starting LiDAR system (attempt {self.lidar_init_attempts + 1}/{self.max_init_attempts})...")
        self.lidar_init_attempts += 1
        lidar_system = WorkingLidarSystem()  # Use WORKING implementation
        
        if lidar_system.start():
            print("✅ LiDAR system started successfully")
            time.sleep(3.0)  # Give time to stabilize
            self.blackboard.set("LIDAR_SYSTEM", lidar_system)
            self.lidar_init_attempts = 0  # Reset on success
            return lidar_system
        else:
            print("❌ LiDAR system failed to start")
            return None

    def get_or_create_lidar_renderer(self):
        """Get WORKING renderer using LidarTestBehavior approach"""
        if self.blackboard.exists("LIDAR_RENDERER"):
            renderer = self.blackboard.get("LIDAR_RENDERER")
            if renderer and hasattr(renderer, 'display_owned') and renderer.display_owned:
                return renderer
            else:
                # Clean up old renderer
                if renderer and hasattr(renderer, 'release_display'):
                    renderer.release_display()
                self.blackboard.unset("LIDAR_RENDERER")

        try:
            # Create WORKING exclusive renderer using LidarTestBehavior approach
            renderer = ExclusivePygameLidarRenderer()
            self.blackboard.set("LIDAR_RENDERER", renderer)
            print("✅ WORKING LiDAR renderer created using LidarTestBehavior approach!")
            return renderer
        except Exception as e:
            print(f"❌ Failed to create working renderer: {e}")
            return None

    def calculate_target_position(self, target_person: dai.SpatialImgDetection) -> Position:
        """Calculate target position with proper coordinate transformation"""
        try:
            x_camera = target_person.spatialCoordinates.x
            z_camera = target_person.spatialCoordinates.z
            
            angle_rad = math.atan2(x_camera, z_camera)
            distance = max(100, z_camera - 400)  # Account for robot geometry
            
            return Position(angle=angle_rad, distance=distance)
            
        except Exception as e:
            return None

    def update(self) -> Status:
        """WORKING update loop with proper ESC handling and LiDAR management"""
        try:
            # Handle pygame events INCLUDING ESC - we need direct control
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        print("🛑 ESC pressed - exiting LiDAR Chase mode...")
                        return Status.FAILURE  # Exit cleanly
                elif event.type == pygame.QUIT:
                    return Status.FAILURE
            
            self.update_count += 1
            
            # Get WORKING renderer using LidarTestBehavior approach
            renderer = self.get_or_create_lidar_renderer()
            if not renderer:
                print("❌ Working renderer unavailable - will retry next update")
                return Status.RUNNING

            # Get WORKING LiDAR system - keep it alive!
            lidar_system = self.get_or_create_lidar_system()
            obstacles = []
            if lidar_system and lidar_system.running:
                # Get obstacle data from WORKING LiDAR
                lidar_obstacles = lidar_system.get_latest_obstacles()
                if lidar_obstacles is not None:
                    obstacles = lidar_obstacles
                    if self.update_count % 100 == 0:  # Debug every 100 updates
                        print(f"📡 LiDAR active: {len(obstacles)} obstacles detected")
                else:
                    # LiDAR running but no data yet
                    obstacles = []
            else:
                # LiDAR system not ready yet - keep trying but don't fail
                if self.update_count % 50 == 0:  # Only print every 50 updates
                    print("⏳ LiDAR system initializing...")

            # Get target position
            target_position = None
            try:
                target_person: dai.SpatialImgDetection = self.blackboard.get("TARGET_PERSON")
                target_position = self.calculate_target_position(target_person)
            except KeyError:
                pass
            except Exception as e:
                pass

            # Get path
            path = None
            try:
                path = self.blackboard.get("PATH")
                if not isinstance(path, list):
                    path = None
            except KeyError:
                pass

            # WORKING render frame using LidarTestBehavior approach
            renderer.render_frame(obstacles, target_position, path, lidar_system)
            
            # Return RUNNING to keep the display active until ESC is pressed
            return Status.RUNNING
            
        except Exception as e:
            print(f"❌ Update error: {e}")
            import traceback
            traceback.print_exc()
            return Status.RUNNING

    def terminate(self, new_status: Status):
        """Clean shutdown without restart prevention"""
        try:
            print("🧹 Terminating LiDAR plot cleanly...")
            
            # Release WORKING display control
            if self.blackboard.exists("LIDAR_RENDERER"):
                renderer = self.blackboard.get("LIDAR_RENDERER")
                if renderer and hasattr(renderer, 'release_display'):
                    renderer.release_display()
                self.blackboard.unset("LIDAR_RENDERER")
                print("✅ Display renderer shut down")
            
            # Stop LiDAR system properly
            if self.blackboard.exists("LIDAR_SYSTEM"):
                lidar_system = self.blackboard.get("LIDAR_SYSTEM")
                if lidar_system:
                    print("🛑 Stopping LiDAR system...")
                    lidar_system.stop()
                    time.sleep(1)  # Give time for proper shutdown
                self.blackboard.unset("LIDAR_SYSTEM")
                print("✅ LiDAR system shut down")
            
            # Clear pygame events
            try:
                pygame.event.clear()
                print("✅ Pygame events cleared")
            except Exception:
                pass
            
            print("✅ Clean shutdown complete")
            
        except Exception as e:
            print(f"❌ Cleanup error: {e}")
        
        super().terminate(new_status)