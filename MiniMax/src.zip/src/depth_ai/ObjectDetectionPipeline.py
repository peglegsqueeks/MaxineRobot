from enum import Enum
from ..depth_ai.DepthAiPipeline import DepthAiPipeline
import depthai as dai
from typing import Dict
import os
import glob


class ObjectDetectionPipeline(DepthAiPipeline):
    """
    A DAI pipeline for object detection with dual mono cameras and enhanced depth perception
    """

    @staticmethod
    def find_best_compatible_model():
        """Find the best compatible model"""
        original_mobilenet = "/home/jetson/depthai-python/examples/models/mobilenet-ssd_openvino_2021.4_6shave.blob"
        if os.path.exists(original_mobilenet):
            return original_mobilenet
        
        compatible_models = [
            "/home/jetson/models/compatible-person-detection.blob",
            "/home/jetson/models/person-detection-0200.blob",
            "/home/jetson/models/person-detection.blob",
        ]
        
        for path in compatible_models:
            if os.path.exists(path):
                return path
        
        blob_files = glob.glob("/home/jetson/models/*.blob")
        if blob_files:
            non_yolo_models = [f for f in blob_files if 'yolov5' not in f.lower()]
            if non_yolo_models:
                return non_yolo_models[0]
        
        return original_mobilenet

    def __init__(self):
        self.SPATIAL_NETWORK_PATH = self.find_best_compatible_model()
        self.expected_input_size = 300
        # Set minimum confidence to 65% as requested
        self.minimum_confidence = 0.65
        super().__init__()

    class ObjectDetectionQueues(Enum):
        IMAGE_OUT = "image_out"
        OBJECT_OUT = "object_out"
        DEPTH_OUT = "depth_out"
        LEFT_MONO_OUT = "left_mono_out"
        RIGHT_MONO_OUT = "right_mono_out"

    def make_detection_net(self) -> dai.node.MobileNetSpatialDetectionNetwork:
        """
        Makes a spatial detection network optimized for person detection with 65% confidence
        """
        # Set confidence threshold to 65% as requested
        confidence_threshold = self.minimum_confidence  # 0.65
        queue_size = 4  # Smaller queue for lower latency
        
        model_name = os.path.basename(self.SPATIAL_NETWORK_PATH).lower()
        expected_input_size = 300
        
        # Model-specific settings, but always use minimum 65% confidence
        if "mobilenet" in model_name:
            expected_input_size = 300
        elif "person-detection" in model_name:
            expected_input_size = 256
        else:
            expected_input_size = 256

        self.expected_input_size = expected_input_size

        try:
            spatial_net: dai.node.MobileNetSpatialDetectionNetwork = self.make_net(
                dai.node.MobileNetSpatialDetectionNetwork,
                self.SPATIAL_NETWORK_PATH,
                confidence_threshold,
                queue_size,
                blocking=False,
            )

            # Optimized settings for accurate person detection
            spatial_net.setBoundingBoxScaleFactor(0.3)
            spatial_net.setDepthLowerThreshold(300)  # 30cm minimum
            spatial_net.setDepthUpperThreshold(8000)  # 8m maximum for person detection

            return spatial_net
            
        except Exception as e:
            print(f"❌ Error creating detection network: {e}")
            raise

    def configure(self):
        """
        Configure pipeline to use BOTH left and right mono cameras with depth perception
        """
        try:
            # Build BOTH mono cameras with THE_800_P for maximum wide FOV
            left_mono = self.make_mono_camera("left")
            right_mono = self.make_mono_camera("right")
            
            # INCREASED FPS for faster real-time response
            left_mono.setFps(30)
            right_mono.setFps(30)
            
            # Build stereo sensor optimized for wide-angle depth perception
            stereo_sensor = self.make_stereo_sensor()
            
            # Build detection network with 65% confidence
            detection_net = self.make_detection_net()
            
            # Build image manipulation for the network input
            input_size = getattr(self, 'expected_input_size', 300)
            image_manip = self.make_image_manip(input_size, False) # keep existing aspect ratio

            # Link the pipeline: Both mono cameras -> stereo -> detection
            left_mono.out.link(stereo_sensor.left)
            right_mono.out.link(stereo_sensor.right)
            
            # Use the right camera for image processing (standard practice)
            stereo_sensor.rectifiedRight.link(image_manip.inputImage)
            image_manip.out.link(detection_net.input)
            stereo_sensor.depth.link(detection_net.inputDepth)

            # Build outputs with optimized queue sizes
            self.make_output(image_manip.out, self.ObjectDetectionQueues.IMAGE_OUT.value)
            self.make_output(detection_net.out, self.ObjectDetectionQueues.OBJECT_OUT.value)
            self.make_output(detection_net.passthroughDepth, self.ObjectDetectionQueues.DEPTH_OUT.value)
            
            # Add direct mono camera outputs for debugging/monitoring
            self.make_output(left_mono.out, self.ObjectDetectionQueues.LEFT_MONO_OUT.value)
            self.make_output(right_mono.out, self.ObjectDetectionQueues.RIGHT_MONO_OUT.value)
            
        except Exception as e:
            raise

    def get_output_queues(
        self, device: dai.Device
    ) -> Dict[ObjectDetectionQueues, dai.DataOutputQueue]:
        """
        Get all output queues optimized for MAXIMUM SPEED
        """
        try:
            queues = {}
            for queue_type in self.ObjectDetectionQueues:
                try:
                    # MINIMAL queues for maximum responsiveness
                    queue = device.getOutputQueue(queue_type.value, maxSize=1, blocking=False)
                    queues[queue_type] = queue
                except Exception as e:
                    pass
            
            return queues
            
        except Exception as e:
            raise