import time
import math
import matplotlib.pyplot as plt
import numpy as np
from typing import List
from .Position import Position


class LidarPlot:
    """
    Optimized LiDAR plotting system with balanced performance and stable obstacle mapping
    Simplified version that works with Maxine's threading system
    """
    
    def __init__(self, range_mm: int = 7000, debug_algo_path=False):
        self.range = range_mm
        self.debug_algo_path = debug_algo_path
        
        # Simplified plotting parameters
        self.last_update = time.time()
        self.update_interval = 0.1  # 10 FPS to prevent overwhelming
        self.is_initialized = False
        
        self.init_optimized_plot()
        
        print("Optimized LiDAR Plot initialized")

    def init_optimized_plot(self):
        """Initialize simplified plotting system"""
        try:
            plt.ion()  # Interactive mode for real-time updates
            
            # Create figure with optimal size
            self.fig = plt.figure(figsize=(8, 8))
            
            # Single optimized polar plot
            self.ax = plt.subplot(111, projection='polar')
            
            # Configure polar plot
            self.ax.set_theta_zero_location("N")
            self.ax.set_theta_direction(-1)
            self.ax.set_xticks(np.radians(np.arange(0, 360, 45)))
            
            # Distance configuration
            range_points = [(i + 1) * self.range / 4 for i in range(4)]
            self.ax.set_yticks(range_points)
            self.ax.set_rmax(self.range)
            self.ax.set_rticks(range_points)
            
            # Grid and styling
            self.ax.grid(True, alpha=0.3)
            self.ax.set_title("Maxine LiDAR - Optimized View", fontsize=12)
            
            # Initialize plot elements
            self.obstacles_plot, = self.ax.plot([], [], 'bo', markersize=1.2, alpha=0.8)
            self.destination_plot, = self.ax.plot([], [], 'r*', markersize=12)
            self.path_plot, = self.ax.plot([], [], 'r-', linewidth=2, alpha=0.8)
            
            plt.tight_layout()
            
            # Show plot - let matplotlib manage the window
            plt.show(block=False)
            
            self.is_initialized = True
            
        except Exception as e:
            print(f"Error initializing LiDAR plot: {e}")
            self.is_initialized = False

    def plot_obstacles(self, readings: List[Position]):
        """Plot obstacles with rate limiting"""
        if not self.is_initialized:
            return
            
        current_time = time.time()
        
        # Rate limiting for performance
        if current_time - self.last_update < self.update_interval:
            return
            
        try:
            if readings:
                # Convert Position objects to angles and distances
                angles = [reading.angle for reading in readings]
                distances = [reading.distance for reading in readings]
                
                # Update obstacles
                self.obstacles_plot.set_data(angles, distances)
                
                # Update title
                self.ax.set_title(f"Maxine LiDAR - {len(readings)} obstacles", fontsize=12)
            else:
                # Clear obstacles
                self.obstacles_plot.set_data([], [])
                self.ax.set_title("Maxine LiDAR - No obstacles", fontsize=12)
                
            self.last_update = current_time
            
        except Exception as e:
            print(f"Error plotting obstacles: {e}")

    def plot_destination(self, destination: Position):
        """Plot target destination"""
        if not self.is_initialized:
            return
            
        try:
            if destination:
                self.destination_plot.set_data([destination.angle], [destination.distance])
            else:
                self.destination_plot.set_data([], [])
        except Exception as e:
            print(f"Error plotting destination: {e}")

    def plot_path(self, path: List[Position]):
        """Plot navigation path"""
        if not self.is_initialized:
            return
            
        try:
            if path and len(path) > 1:
                angles = [pos.angle for pos in path]
                distances = [pos.distance for pos in path]
                self.path_plot.set_data(angles, distances)
            else:
                self.path_plot.set_data([], [])
        except Exception as e:
            print(f"Error plotting path: {e}")

    def update_plot(self):
        """Simple plot update"""
        if not self.is_initialized:
            return
            
        try:
            # Simple drawing update
            self.fig.canvas.draw_idle()
            self.fig.canvas.flush_events()
            
        except Exception as e:
            print(f"Error updating plot: {e}")

    def plot_obstacles_debug(self, readings, original_obs_debug):
        """Legacy compatibility - no debug plotting"""
        pass

    def plot_destination_debug(self, destination):
        """Legacy compatibility - no debug plotting"""
        pass

    def plot_path_debug(self, path):
        """Legacy compatibility - no debug plotting"""
        pass

    def close(self):
        """Simple cleanup"""
        try:
            if hasattr(self, 'fig') and plt.fignum_exists(self.fig.number):
                plt.close(self.fig)
            self.is_initialized = False
            print("LiDAR plot closed")
        except Exception as e:
            print(f"Error closing plot: {e}")