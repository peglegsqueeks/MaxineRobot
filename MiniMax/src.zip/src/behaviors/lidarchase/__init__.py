"""
Enhanced LiDAR Chase Module - COMPLETE REPLACEMENT

This module provides the complete enhanced LiDAR chase system with:
- Enhanced zoom and visibility  
- Stable obstacle detection (no flickering red dots)
- Coordinated exit handling
- 10cm safety buffer
- Faster robot movement
- Works with existing LIDARCHASE mode (mode 4)
"""

# Import the enhanced LiDAR chase behavior
from .LidarChaseBehavior import LidarChaseBehavior

# Import utilities
import py_trees
from py_trees.composites import Selector, Sequence
from src.behaviors.SetRobotMode import SetRobotMode
from src.types.RobotModes import RobotMode
from src.types.MovementDirection import MovementDirection

# Try to import legacy components for backward compatibility
try:
    from src.behaviors.chase_mode.AnnounceFoundPerson import AnnounceFoundPerson
    from src.behaviors.chase_mode.SelectPerson import SelectPerson
    from src.behaviors.chase_mode.HasReachedPerson import HasReachedPerson
    from ..MoveBehavior import MoveBehavior
except ImportError:
    # Create fallbacks if not available
    class AnnounceFoundPerson:
        def update(self): return py_trees.common.Status.SUCCESS
    class SelectPerson:  
        def update(self): return py_trees.common.Status.SUCCESS
    class HasReachedPerson:
        def __init__(self, threshold): pass
        def update(self): return py_trees.common.Status.FAILURE
    class MoveBehavior:
        def __init__(self, direction): pass
        def update(self): return py_trees.common.Status.SUCCESS


def make_enhanced_target_reached_sub_tree():
    """Create enhanced target reached handler"""
    try:
        target_is_close = HasReachedPerson(500)
        stop_moving = MoveBehavior(MovementDirection.NONE)
        announce_found_person = AnnounceFoundPerson()
        exit_to_idle = SetRobotMode(RobotMode.IDLE)
        
        return Sequence(
            "Enhanced Target Reached",
            memory=True,
            children=[
                target_is_close,
                stop_moving,
                announce_found_person,
                exit_to_idle
            ],
        )
    except Exception as e:
        print(f"⚠️ Target reached handler fallback: {e}")
        return SetRobotMode(RobotMode.IDLE)


def make_person_detection_sub_tree():
    """Create person detection subtree"""
    try:
        return Sequence(
            "Person Detection",
            memory=True,
            children=[
                SelectPerson(),
            ],
        )
    except Exception as e:
        print(f"⚠️ Person detection fallback: {e}")
        return SelectPerson()


def make_enhanced_chase_sequence():
    """Create the main enhanced chase sequence"""
    try:
        person_detection = make_person_detection_sub_tree()
        main_chase = LidarChaseBehavior()  # This is the ENHANCED system
        
        return Sequence(
            "Enhanced Chase Sequence", 
            memory=True,
            children=[
                person_detection,
                main_chase
            ],
        )
    except Exception as e:
        print(f"⚠️ Enhanced chase sequence fallback: {e}")
        return LidarChaseBehavior()


def make_main_chase_loop():
    """Create main chase loop with target detection"""
    try:
        target_reached = make_enhanced_target_reached_sub_tree()
        chase_sequence = make_enhanced_chase_sequence()
        
        return Selector(
            "Main Chase Loop",
            memory=True,
            children=[
                target_reached,
                chase_sequence,
            ],
        )
    except Exception as e:
        print(f"⚠️ Main chase loop fallback: {e}")
        return LidarChaseBehavior()


def make_lidar_chase_sub_tree():
    """
    MAIN FACTORY FUNCTION - Creates the enhanced LiDAR chase behavior tree
    
    This replaces the old complex multi-file system with the new unified approach.
    
    Features:
    - Enhanced zoom (much larger obstacle display)
    - Stable obstacles (no flickering red dots)
    - Coordinated exit handling (proper ESC key response)
    - 10cm safety buffer
    - Yellow path with white waypoints
    - Proper LiDAR motor shutdown
    
    Returns:
        Enhanced LiDAR chase behavior (single integrated system)
    """
    try:
        print("🚀 Loading ENHANCED LiDAR Chase System...")
        enhanced_system = LidarChaseBehavior()
        print("✅ Enhanced LiDAR Chase System loaded (better zoom, stable obstacles, coordinated exit)")
        return enhanced_system
    except Exception as e:
        print(f"❌ Enhanced LiDAR Chase System failed to load: {e}")
        print("🔄 Using fallback system...")
        # Return a basic fallback
        return SetRobotMode(RobotMode.IDLE)


def make_working_lidar_chase_sub_tree():
    """
    Alternative factory function name for compatibility
    """
    return make_lidar_chase_sub_tree()


def make_lidar_chase_behavior_tree():
    """
    Alternative factory using the main chase loop
    """
    return make_main_chase_loop()


def configure_working_chase_system():
    """Configure the enhanced chase system"""
    try:
        from src.path_finding.new_a_star import configure_robot_dimensions
        configure_robot_dimensions(
            width=500,          # 50cm robot width
            length=650,         # 65cm robot length
            safety_buffer=100   # 10cm buffer
        )
        print("✅ Enhanced chase system configured for existing LIDARCHASE mode")
    except Exception as e:
        print(f"⚠️ Configuration warning: {e}")


def get_working_system_info():
    """Get information about the enhanced system"""
    return {
        "version": "Enhanced LiDAR Chase System v2.0",
        "robot_mode": "Uses existing LIDARCHASE mode (mode 4)",
        "main_factory": "make_lidar_chase_sub_tree",
        "features": [
            "Enhanced zoom (display scale //12 instead of //20)",
            "Stable obstacles (no flickering red dots)",
            "Coordinated exit handling (proper ESC key response)",
            "10cm safety buffer",
            "Yellow path with white waypoints", 
            "Proper LiDAR motor shutdown",
            "Thread-safe pathfinding",
            "Integrated person detection",
            "Compatible with existing LIDARCHASE mode"
        ],
        "improvements": {
            "zoom": "Much larger obstacle display for better visibility",
            "stability": "Advanced confidence tracking prevents flickering",
            "exit": "Coordinated pygame event handling with timeout",
            "navigation": "Faster pathfinding with smaller safety buffer",
            "cleanup": "Proper hardware shutdown sequences",
            "compatibility": "Works with existing LIDARCHASE mode (mode 4)"
        }
    }


# Auto-configure on import
configure_working_chase_system()

# Export main functions
__all__ = [
    # PRIMARY FACTORY FUNCTIONS - Use these in your main behavior tree
    'make_lidar_chase_sub_tree',              # MAIN: Use this for primary integration
    'make_working_lidar_chase_sub_tree',      # Same as above, explicit name
    'make_lidar_chase_behavior_tree',         # Alternative with chase loop
    
    # Sub-tree factories
    'make_enhanced_target_reached_sub_tree',
    'make_person_detection_sub_tree', 
    'make_enhanced_chase_sequence',
    'make_main_chase_loop',
    
    # Core classes
    'LidarChaseBehavior',                     # Main enhanced behavior class
    
    # Configuration
    'configure_working_chase_system',         # System configuration
    'get_working_system_info',                # System information
]

# Print system info on import
if __name__ != "__main__":
    info = get_working_system_info()
    print(f"📦 {info['version']} loaded")
    print(f"🎯 Main factory function: {info['main_factory']}")
    print(f"🤖 Robot mode: {info['robot_mode']}")

# Legacy compatibility - keep old function names working
try:
    # Try to import old components for backward compatibility
    from .UpdateLidarPlot import UpdateLidarPlot
    from .PathFind import FixedPathFind, PathFind
    from .FollowPathBehvior import FasterFollowPathBehavior, FollowPathBehavior  
    from .CloseLidarPlot import FixedCloseLidarPlot, CloseLidarPlot
    print("📦 Legacy LiDAR chase components available as fallbacks")
except ImportError:
    # Legacy components not available - enhanced system will be used
    UpdateLidarPlot = None
    FixedPathFind = None
    PathFind = None
    FasterFollowPathBehavior = None
    FollowPathBehavior = None
    FixedCloseLidarPlot = None
    CloseLidarPlot = None
    print("📦 Using enhanced LiDAR chase system (legacy components not found)")

print("🚀 Enhanced LiDAR Chase Module Ready!")