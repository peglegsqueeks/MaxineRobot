"""
Main behavior tree for LIDARCHASE mode
This file should be imported by the main behavior tree system
"""

from src.behaviors.lidarchase.LidarChaseTree import create_lidar_chase_behavior_tree


def make_lidarchase_behavior_tree():
    """
    Create the behavior tree for LIDARCHASE mode
    This is the main function that should be called by the behavior tree system
    """
    return create_lidar_chase_behavior_tree()


def make_lidar_chase_sub_tree():
    """
    Alternative name for compatibility
    """
    return create_lidar_chase_behavior_tree()


# Export the main functions
__all__ = [
    "make_lidarchase_behavior_tree",
    "make_lidar_chase_sub_tree"
]