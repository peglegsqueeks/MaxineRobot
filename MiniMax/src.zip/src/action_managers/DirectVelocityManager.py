import time
from ..types.MovementDirection import MovementDirection
from ..action_managers.VelocityManager import VelocityConfig
from ..action_managers.ActionManager import ActionManager
import Jetson.GPIO as GPIO
import motoron


class DirectVelocityManager(ActionManager):
    REFERENCE_MV = 3300
    PIN= 7
    TYPE = motoron.CurrentSenseType.MOTORON_24V16
    VIN_TYPE = motoron.VinSenseType.MOTORON_HP
    
    MAX_ACCELERATION = 50
    MAX_DECELERATION = 40
    CURRENT_LIMIT= 15000

# I have adjusted speed of all motors down, to slow down robot.
# This is to ensure that turning robot doesn't overshoot target.
    DIRECTION_TO_MOTOR_SPEED = {
        MovementDirection.NONE: (0, 0),
        MovementDirection.FORWARDS: (-200, -196),
        MovementDirection.RIGHT: (170, -170),
        MovementDirection.LEFT: (-170, 170),
        MovementDirection.FORWARDS_LEFT: (-270,-200),
        MovementDirection.BACKWARDS_LEFT: (300, 200),
        MovementDirection.BACKWARDS: (200, 200),
        MovementDirection.BACKWARDS_RIGHT: (-170, -205),
        MovementDirection.FORWARDS_RIGHT: (-170, -205),
    }

    

    def __init__(self, version, maxaccel, maxdecel, current_limit, simulate=False) -> None:
        self.name = "Direct Motor Control Velocity Manager"
        self.TYPE=motoron.CurrentSenseType.MOTORON_24V16
        self.CURRENT_LIMIT=current_limit
        self.MAX_ACCELERATION=maxaccel
        self.MAX_DECELERATION=maxdecel
        self.simulate=simulate
        GPIO.setmode(GPIO.BOARD)  
        GPIO.setup(self.PIN, GPIO.OUT)
        if not self.simulate:
            self.initialise_motor_control()
            self.turn_brake_off()
        
    

    def shutdown(self):

        if self.simulate:
            print('simulated shutdown and brake on')
            self.turn_brake_on() 
            return

        self.mc.set_speed(1, 0)
        self.mc.set_speed(2, 0)
        self.turn_brake_on()
        print('shutdown and brake on')

    def turn_brake_on(self):
        # brake line goes off to turn brake on (due to safety feature)
        GPIO.output(self.PIN, GPIO.LOW)  # Set the pin to LOW (brake on)
        print('brake on')
        
	
    def turn_brake_off(self):
        # brake line goes on to turn brake off (due to safety feature)
        GPIO.output(self.PIN, GPIO.HIGH)  # Set the pin to LOW (brake on)
        print('brake off')

    def initialise_motor_control(self):

        if not self.simulate:
            self.turn_brake_off() 
            #initialise the motor controller
            self.mc = motoron.MotoronI2C(bus=7)
            self.mc.reinitialize() 
            self.mc.disable_crc()
            self.mc.clear_reset_flag()
            self.mc.disable_command_timeout()

            # configure both motors 
            self.configure_motor(1)
            self.configure_motor(2) 
            print('init motoron')
        else:
            print('Simulate init motoron controller')

    def configure_motor(self, motor_id):
        
        print('config motoron')
        # clear motor status
        self.mc.clear_motor_fault()
        
        # set acceleration / deceleration maximums
        self.mc.set_max_acceleration(motor_id, self.MAX_ACCELERATION)
        self.mc.set_max_deceleration(motor_id, self.MAX_DECELERATION)

        # set currnet limit on motor by calculating each motor's offset first. Motors must be in zero state.
        # set motors to zero
        self.mc.set_braking(motor_id,0)
        self.mc.set_speed(motor_id, 0)
        current_offset = self.mc.get_current_sense_offset(motor_id)
        #print('The current offset for motor ',motor_id,' is ', current_offset)
        limit = motoron.calculate_current_limit(self.CURRENT_LIMIT, self.TYPE, self.REFERENCE_MV, current_offset)
        self.mc.set_current_limit(motor_id, limit)
        #print("The current limit " , int(limit))
        

    def perform_action(self, config: VelocityConfig):

        #print('perform action')
        direction = config.direction
        speed = config.speed
        motor_1, motor_2 = self.DIRECTION_TO_MOTOR_SPEED[direction]

        motor_1 = int(motor_1 * speed)
        motor_2 = int(motor_2 * speed)

        if motor_1 < 0:
            motor_1 = max(-800, motor_1)
        else:
            motor_1 = min(800, motor_1)

        if motor_2 < 0:
            motor_2 = max(-800, motor_2)
        else:
            motor_2 = min(800, motor_2)

        if self.simulate:
            if direction == MovementDirection.NONE:
                print("[Sim] Stopped")
            elif direction == MovementDirection.FORWARDS:
                print("[Sim] Moving forward")
            elif direction == MovementDirection.BACKWARDS:
                print("[Sim] Moving backward")
            elif direction == MovementDirection.LEFT:
                print("[Sim] Turning left")
            elif direction == MovementDirection.RIGHT:
                print("[Sim] Turning right")
            elif direction == MovementDirection.FORWARDS_LEFT:
                print("[Sim] Forward-left")
            elif direction == MovementDirection.FORWARDS_RIGHT:
                print("[Sim] Forward-right")
            elif direction == MovementDirection.BACKWARDS_LEFT:
                print("[Sim] Backward-left")
            elif direction == MovementDirection.BACKWARDS_RIGHT:
                print("[Sim] Backward-right")
            else:
                print(f"[Sim] Unknown direction: {direction}")
            return
        #print('perform action')
        # set left speed & braking when speed is 0
        #self.mc.set_braking(1,0)
        self.mc.set_speed(1, motor_1)
        #time.sleep(.01)
        #VOLTAGE_MV = self.mc.get_vin_voltage_mv(self.REFERENCE_MV, self.VIN_TYPE)
        #self.mc.set_current_sense_minimum_divisor(1,800)
        #AMPS_MV = self.mc.get_current_sense_processed(1)
        #print("current voltage motor 1 is ", int(VOLTAGE_MV))
        #print("current AMPS motor 1 is ", int(AMPS_MV*161))

        # set right speed & braking when speed is 0
        #self.mc.set_braking(2,0)
        self.mc.set_speed(2, motor_2)
        #time.sleep(.01)
        #VOLTAGE_MV = self.mc.get_vin_voltage_mv(self.REFERENCE_MV, self.VIN_TYPE)
        #self.mc.set_current_sense_minimum_divisor(2,800)
        #AMPS_MV = self.mc.get_current_sense_processed(2)
        #print("current voltage motor 2 is ", int(VOLTAGE_MV))
        #print("current AMPS motor 2 is ", int(AMPS_MV*161))
        
