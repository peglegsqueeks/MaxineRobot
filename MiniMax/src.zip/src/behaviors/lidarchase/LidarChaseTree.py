"""
LiDAR Chase Behavior Tree Integration
This file provides the behavior tree that handles LIDARCHASE mode
"""

import py_trees
from py_trees.common import Status
from py_trees.composites import Selector, Sequence
from src.behaviors.MaxineBehavior import MaxineBehavior
from src.behaviors.SetRobotMode import SetRobotMode
from src.behaviors.lidarchase.LidarChaseBehavior import LidarChaseBehavior
from src.types.RobotModes import RobotMode
from src.types.MovementDirection import MovementDirection
from src.action_managers.VelocityManager import VelocityConfig
import depthai as dai
import time


class PersonDetectionBehavior(MaxineBehavior):
    """Person detection for LiDAR chase"""
    
    def __init__(self):
        super().__init__("Person Detection")
        self.blackboard.register_key("TARGET_PERSON", access=py_trees.common.Access.WRITE)
    
    def update(self) -> Status:
        try:
            robot = self.get_robot()
            
            # Get camera reading
            camera_reading = robot.camera_sensor.get_reading()
            
            if camera_reading:
                # Get people locations
                people = camera_reading.get_people_locations()
                
                if people:
                    # Use the first (closest) person
                    target_person = people[0]
                    self.blackboard.set("TARGET_PERSON", target_person)
                    return Status.SUCCESS
                else:
                    # No person found, clear target
                    try:
                        self.blackboard.unset("TARGET_PERSON")
                    except:
                        pass
                    return Status.FAILURE
            else:
                # No camera reading available
                return Status.FAILURE
                
        except Exception as e:
            print(f"❌ Person detection error: {e}")
            return Status.FAILURE


class TargetReachedChecker(MaxineBehavior):
    """Check if target is reached"""
    
    def __init__(self, threshold_mm=500):
        super().__init__("Target Reached Checker")
        self.threshold_mm = threshold_mm
        self.blackboard.register_key("TARGET_PERSON", access=py_trees.common.Access.READ)
    
    def update(self) -> Status:
        try:
            target_person: dai.SpatialImgDetection = self.blackboard.get("TARGET_PERSON")
            
            if target_person:
                spatial_coords = getattr(target_person, 'spatialCoordinates', None)
                if spatial_coords:
                    z_distance = getattr(spatial_coords, 'z', float('inf'))
                    
                    if z_distance <= self.threshold_mm:
                        # Target reached - stop robot and announce
                        robot = self.get_robot()
                        
                        # Stop movement
                        if robot.velocity_manager:
                            stop_config = VelocityConfig(MovementDirection.NONE, 0.0)
                            robot.velocity_manager.perform_action(stop_config)
                        
                        # Announce success
                        if robot.speech_manager:
                            robot.speech_manager.perform_action("Person reached!")
                        
                        # Wait a moment then switch to IDLE
                        time.sleep(2.0)
                        robot.set_mode(RobotMode.IDLE)
                        
                        return Status.SUCCESS
                    else:
                        return Status.FAILURE
                else:
                    return Status.FAILURE
            else:
                return Status.FAILURE
                
        except KeyError:
            return Status.FAILURE
        except Exception as e:
            print(f"❌ Target reached checker error: {e}")
            return Status.FAILURE


class LidarChaseSequence(Sequence):
    """
    Main LiDAR chase sequence that coordinates all components
    """
    
    def __init__(self):
        # Create the behavior sequence
        person_detection = PersonDetectionBehavior()
        lidar_chase = LidarChaseBehavior()
        
        super().__init__(
            "LiDAR Chase Sequence",
            memory=True,
            children=[
                person_detection,
                lidar_chase
            ]
        )


class LidarChaseSelector(Selector):
    """
    Main LiDAR chase selector that handles target reached vs continuing chase
    """
    
    def __init__(self):
        # Create components
        target_reached = TargetReachedChecker(500)  # 50cm threshold
        chase_sequence = LidarChaseSequence()
        
        super().__init__(
            "LiDAR Chase Selector",
            memory=True,
            children=[
                target_reached,  # Check if target reached first
                chase_sequence   # Otherwise continue chasing
            ]
        )


def create_lidar_chase_behavior_tree():
    """
    Create the complete LiDAR chase behavior tree
    This is the main function that should be called by the behavior tree system
    """
    return LidarChaseSelector()


def create_simple_lidar_chase_behavior():
    """
    Create a simple LiDAR chase behavior (just the main behavior)
    """
    return LidarChaseBehavior()


def create_lidar_chase_sequence():
    """
    Create the LiDAR chase sequence
    """
    return LidarChaseSequence()


# Export the main functions
__all__ = [
    "create_lidar_chase_behavior_tree",
    "create_simple_lidar_chase_behavior", 
    "create_lidar_chase_sequence",
    "LidarChaseBehavior",
    "PersonDetectionBehavior",
    "TargetReachedChecker"
]