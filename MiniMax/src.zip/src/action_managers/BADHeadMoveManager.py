import time
import logging
from .ActionManager import ActionManager
from typing import Optional
from ..types.HeadMovementDirection import HeadMovementDirection

class HeadVelocityManager(ActionManager[HeadMovementDirection]):

    DIRECTION_TO_SERVO_VALUES = {
        HeadMovementDirection.NONE: (0),
        HeadMovementDirection.LEFT: (0.02),
        HeadMovementDirection.RIGHT: (-0.02),
    }

    def __init__(self, servo_channel: int, board=None, max_retries: int = 5, retry_delay: float = 0.5):
        self.servo_channel = servo_channel
        self.board = board  # Add board reference
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.logger = logging.getLogger(f"HeadVelocityManager_{servo_channel}")
        
        # Initialize current position tracking
        self.current_head_position = 0.0  # Start at center position
        
        # Initialize servo connection with retries
        self._initialize_servo_connection()
        
        # Center the head with robust error handling
        self.center_head()
    
    def _initialize_servo_connection(self):
        """Initialize servo connection with retries for post-boot stability"""
        for attempt in range(self.max_retries):
            try:
                # Add delay for servo controller to stabilize after boot
                if attempt > 0:
                    self.logger.info(f"Servo initialization attempt {attempt + 1}/{self.max_retries}")
                    time.sleep(self.retry_delay * (attempt + 1))  # Progressive delay
                
                # Test servo communication
                position = self._get_servo_position_safe()
                if position is not None:
                    self.current_head_position = position  # Update current position
                    self.logger.info(f"Servo channel {self.servo_channel} initialized successfully at position {position}")
                    return
                
            except Exception as e:
                self.logger.warning(f"Servo initialization attempt {attempt + 1} failed: {e}")
        
        self.logger.error(f"Failed to initialize servo after {self.max_retries} attempts")
        # Set default position if initialization fails
        self.current_head_position = 0.0
    
    def _get_servo_position_safe(self) -> Optional[float]:
        """Safely get servo position with error handling"""
        try:
            position = self.get_servo_position()
            
            # Validate the position is a valid number
            if position is None:
                return None
            
            # Ensure it's a float and within reasonable bounds (-1.0 to 1.0 typically)
            position = float(position)
            if not (-2.0 <= position <= 2.0):  # Reasonable servo range
                self.logger.warning(f"Servo position {position} outside expected range")
                return None
            
            return position
            
        except (TypeError, ValueError, AttributeError) as e:
            self.logger.warning(f"Error reading servo position: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Unexpected error reading servo position: {e}")
            return None
    
    def center_head(self, timeout: float = 10.0, tolerance: float = 0.02):
        """Center the head with robust error handling and timeout"""
        self.logger.info("Centering head...")
        start_time = time.time()
        attempts = 0
        max_attempts = 20
        
        try:
            while attempts < max_attempts:
                # Check timeout
                if time.time() - start_time > timeout:
                    self.logger.error(f"Head centering timeout after {timeout}s")
                    break
                
                # Get current position with error handling
                position = self._get_servo_position_safe()
                
                if position is None:
                    attempts += 1
                    self.logger.warning(f"Cannot read servo position (attempt {attempts}/{max_attempts})")
                    
                    # Try to reset/reinitialize servo
                    if attempts % 5 == 0:  # Every 5th attempt
                        self.logger.info("Attempting servo reset...")
                        self._reset_servo()
                    
                    time.sleep(0.2)
                    continue
                
                # Update current position tracking
                self.current_head_position = position
                
                # Check if already centered
                if abs(position) < tolerance:
                    self.logger.info(f"Head centered successfully at position {position:.3f}")
                    return
                
                # Move towards center
                try:
                    target_position = 0.0  # Center position
                    self._move_servo_to_position(target_position)
                    self.current_head_position = target_position  # Update tracking
                    time.sleep(0.1)  # Allow movement time
                    attempts += 1
                    
                except Exception as e:
                    self.logger.error(f"Error moving servo: {e}")
                    attempts += 1
                    time.sleep(0.2)
            
            # Final position check
            final_position = self._get_servo_position_safe()
            if final_position is not None:
                self.current_head_position = final_position
                self.logger.info(f"Head centering completed at position {final_position:.3f}")
            else:
                self.logger.warning("Head centering completed but cannot verify final position")
                # Keep current_head_position at 0.0 (center assumption)
                self.current_head_position = 0.0
                
        except Exception as e:
            self.logger.error(f"Unexpected error during head centering: {e}")
            # Set to center position as fallback
            self.current_head_position = 0.0
    
    def _reset_servo(self):
        """Reset servo connection/settings"""
        try:
            if self.board and hasattr(self.board, 'SetServoPosition3'):
                self.board.SetServoPosition3(0.0)  # Reset to center
            time.sleep(0.5)
            self.logger.info("Servo reset attempted")
        except Exception as e:
            self.logger.warning(f"Servo reset failed: {e}")
    
    def _move_servo_to_position(self, position: float):
        """Move servo to specified position with error handling"""
        try:
            # Clamp position to safe range
            position = max(-1.0, min(1.0, position))
            
            # Use the actual servo movement method
            self.set_servo_position(position)
            
        except Exception as e:
            self.logger.error(f"Failed to move servo to position {position}: {e}")
            raise
    
    def get_servo_position(self) -> Optional[float]:
        """Get current servo position from hardware"""
        try:
            if self.board and hasattr(self.board, 'GetServoPosition3'):
                return self.board.GetServoPosition3()
            else:
                self.logger.warning("Board not available or missing GetServoPosition3 method")
                return self.current_head_position  # Return tracked position as fallback
        except Exception as e:
            self.logger.error(f"Error reading servo position: {e}")
            return None
    
    def set_servo_position(self, position: float):
        """Set servo position on hardware"""
        try:
            if self.board and hasattr(self.board, 'SetServoPosition3'):
                self.board.SetServoPosition3(position)
            else:
                self.logger.warning("Board not available or missing SetServoPosition3 method")
        except Exception as e:
            self.logger.error(f"Error setting servo position to {position}: {e}")
            raise

    def perform_action(self, direction: HeadMovementDirection):
        """
        Moves the robot head in a direction by setting servo values
        """
        try:
            # Get servo step amount for direction
            step_amount = self.DIRECTION_TO_SERVO_VALUES[direction]
            new_position = self.current_head_position + step_amount
            
            # Check bounds (servo limits)
            if new_position > 0.98:
                self.logger.warning(f"Head movement limited: new position {new_position} exceeds right limit (0.98)")
                return

            if new_position < -0.98:
                self.logger.warning(f"Head movement limited: new position {new_position} exceeds left limit (-0.98)")
                return
            
            # Set servo position
            self.current_head_position = new_position
            
            # Send command to hardware
            if self.board and hasattr(self.board, 'SetServoPosition3'):
                self.board.SetServoPosition3(new_position)
                self.logger.debug(f"Head moved to position {new_position:.3f} (direction: {direction})")
            else:
                self.logger.warning("Cannot move head: board not available")
                
        except Exception as e:
            self.logger.error(f"Error performing head action {direction}: {e}")
            # Don't re-raise to prevent behavior tree crashes
    
    def get_current_position(self) -> float:
        """Get current tracked head position"""
        return self.current_head_position
    
    def is_at_limit(self, direction: HeadMovementDirection) -> bool:
        """Check if head is at movement limit for given direction"""
        if direction == HeadMovementDirection.LEFT:
            return self.current_head_position <= -0.98
        elif direction == HeadMovementDirection.RIGHT:
            return self.current_head_position >= 0.98
        return False