# import cv2
from math import radians
import matplotlib

from src.path_finding.LidarPlot import LidarPlot
from src.path_finding.Position import Position

matplotlib.use("TkAgg")

from matplotlib import pyplot as plt
from src.behaviors.MaxineBehavior import MaxineBehavior
from py_trees.common import Status
import depthai as dai
import py_trees


class UpdateLidarPlot(MaxineBehavior):
    def __init__(self):
        """
        Initilialises the behavior
        """
        super().__init__("show lidar plot")

        self.blackboard.register_key(
            "TARGET_PERSON", access=py_trees.common.Access.WRITE
        )
        self.blackboard.register_key("PATH", access=py_trees.common.Access.WRITE)
        self.blackboard.register_key("LIDAR_PLOT", access=py_trees.common.Access.WRITE)

    def get_target_x_center(self) -> float:
        """
        Returns the middle of the current targets x axis coordinate
        """
        target_person: dai.SpatialImgDetection = self.blackboard.get("TARGET_PERSON")
        x_diff = target_person.xmax - target_person.xmin
        return target_person.xmin + (x_diff / 2)

    def get_or_create_lidar_plot(self):
        # if plot already exists, return from blackboard
        if self.blackboard.exists("LIDAR_PLOT"):
            return self.blackboard.get("LIDAR_PLOT")

        # create plot
        lidar_plot = LidarPlot(range_mm=7000)

        self.blackboard.set("LIDAR_PLOT", lidar_plot)
        return lidar_plot

    def update(self) -> Status:
        lidar_plot = self.get_or_create_lidar_plot()

        # plot obstacles
        robot = self.get_robot()
        lidar = robot.lidar_sensor
        readings = lidar.get_reading()
        lidar_plot.plot_obstacles(readings)

        # plot the target person (as a red star)
        try:
            target_person: dai.SpatialImgDetection = self.blackboard.get(
                "TARGET_PERSON"
            )
            distance = target_person.spatialCoordinates.z - 650
            x_center = self.get_target_x_center()

            angle = radians((x_center * 2 - 1) * 63.5)

            destination = Position(angle=angle, distance=distance)
            lidar_plot.plot_destination(destination)
        except KeyError:
            print("Target person missing, cant plot red star")

        # plot path
        try:
            path = self.blackboard.get("PATH")
            lidar_plot.plot_path(path)
        except KeyError:
            print("Path missing, cant plot red line")

        # update plot
        lidar_plot.update_plot()
        return Status.SUCCESS
