import time
import math
import threading
import pygame
import queue
from typing import List, Optional, Tuple, Dict, Set
from enum import Enum

import depthai as dai
import py_trees
from py_trees.common import Status

from src.behaviors.MaxineBehavior import MaxineBehavior
from src.path_finding.Position import Position
from src.path_finding.new_a_star import a_star
from src.action_managers.VelocityManager import VelocityConfig
from src.types.MovementDirection import MovementDirection
from src.types.RobotModes import RobotMode


class LidarChaseState(Enum):
    """States for the LiDAR chase behavior"""
    INITIALIZING = "initializing"
    SCANNING = "scanning"
    PERSON_DETECTED = "person_detected"
    PATHFINDING = "pathfinding"
    NAVIGATING = "navigating"
    TARGET_REACHED = "target_reached"
    EXITING = "exiting"
    ERROR = "error"


class WorkingLidarSystem:
    """
    Working LiDAR system that interfaces with the existing LidarSensor
    """
    
    def __init__(self, robot):
        self.robot = robot
        self.running = False
        self.latest_obstacles = []
        self.data_lock = threading.Lock()
        self.start_time = None
        self.stabilization_period = 4.0  # 4 seconds to stabilize
        
    def start(self):
        """Start the LiDAR system using existing sensor"""
        try:
            if hasattr(self.robot, 'lidar_sensor') and self.robot.lidar_sensor:
                if not self.robot.lidar_sensor.is_initialized:
                    success = self.robot.lidar_sensor.initialize()
                    if success:
                        self.running = True
                        self.start_time = time.time()
                        print("✅ LiDAR system started successfully")
                        return True
                    else:
                        print("❌ Failed to start LiDAR system")
                        return False
                else:
                    self.running = True
                    self.start_time = time.time()
                    print("✅ LiDAR system already running")
                    return True
            else:
                print("❌ No LiDAR sensor available")
                return False
                
        except Exception as e:
            print(f"❌ LiDAR system start error: {e}")
            return False
    
    def is_stabilized(self):
        """Check if LiDAR system has stabilized"""
        if self.start_time is None:
            return False
        return (time.time() - self.start_time) > self.stabilization_period
    
    def get_latest_obstacles(self):
        """Get latest obstacles from LiDAR sensor with stabilization"""
        try:
            if self.robot.lidar_sensor and self.running:
                # Don't return obstacles during stabilization period
                if not self.is_stabilized():
                    return []
                
                obstacles = self.robot.lidar_sensor.get_reading()
                if obstacles:
                    # Keep Position objects - don't convert to tuples yet
                    # The renderer will handle the coordinate transformation
                    with self.data_lock:
                        self.latest_obstacles = obstacles
                    
                    return obstacles
                else:
                    return []
            else:
                return []
                
        except Exception as e:
            print(f"❌ Error getting obstacles: {e}")
            return []
    
    def stop(self):
        """Stop the LiDAR system"""
        try:
            self.running = False
            if self.robot.lidar_sensor:
                self.robot.lidar_sensor.shutdown()
                print("✅ LiDAR system stopped")
        except Exception as e:
            print(f"❌ LiDAR stop error: {e}")


class PygameLidarRenderer:
    """
    Pygame-only LiDAR renderer (no matplotlib)
    """
    
    def __init__(self):
        # Get display info for fullscreen
        display_info = pygame.display.Info()
        self.screen_width = display_info.current_w
        self.screen_height = display_info.current_h
        self.center_x = self.screen_width // 2
        self.center_y = self.screen_height // 2
        
        # Create fullscreen surface
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height), pygame.FULLSCREEN)
        pygame.display.set_caption("MAXINE LIDAR CHASE")
        
        # Display parameters - increased zoom
        self.display_scale = min(self.screen_width, self.screen_height) // 10  # Increased from //15 to //10 for more zoom
        self.max_display_range = 5  # Reduced from 6 to 5 meters for better zoom
        
        # Colors
        self.colors = {
            'background': (0, 0, 0),
            'grid': (0, 120, 0),
            'distance_rings': (0, 180, 0),
            'angle_marks': (0, 220, 0),
            'obstacles': (255, 0, 0),
            'robot': (0, 0, 255),
            'target': (255, 255, 0),
            'path_color': (255, 255, 0),
            'waypoint_color': (255, 255, 255),
            'text': (255, 255, 255),
            'status_good': (0, 255, 0),
            'status_warning': (255, 255, 0),
            'status_danger': (255, 0, 0)
        }
        
        # Fonts
        self.font = pygame.font.Font(None, 48)
        self.small_font = pygame.font.Font(None, 36)
        self.info_font = pygame.font.Font(None, 42)
        
        print(f"✅ Pygame renderer initialized: {self.screen_width}x{self.screen_height}")
    
    def draw_grid(self):
        """Draw distance rings and angle markings"""
        # Distance rings - adjusted for increased zoom
        for distance in [1, 2, 3, 4, 5]:  # Removed 6m ring since max range is now 5m
            radius = distance * self.display_scale
            max_radius = min(self.center_x, self.center_y) - 50
            
            if radius < max_radius:
                pygame.draw.circle(self.screen, self.colors['distance_rings'], 
                                 (self.center_x, self.center_y), radius, 3)
                
                # Distance labels
                text = self.info_font.render(f"{distance}m", True, self.colors['distance_rings'])
                self.screen.blit(text, (self.center_x + radius - 35, self.center_y - 20))
        
        # Angle markings
        max_radius = min(self.center_x, self.center_y) - 80
        for angle in range(0, 360, 30):
            display_angle_rad = math.radians(90 - angle)
            
            start_x = self.center_x + int((max_radius - 40) * math.cos(display_angle_rad))
            start_y = self.center_y - int((max_radius - 40) * math.sin(display_angle_rad))
            end_x = self.center_x + int(max_radius * math.cos(display_angle_rad))
            end_y = self.center_y - int(max_radius * math.sin(display_angle_rad))
            
            line_width = 4 if angle % 90 == 0 else 3
            pygame.draw.line(self.screen, self.colors['angle_marks'], 
                           (start_x, start_y), (end_x, end_y), line_width)
            
            # Angle labels
            text_x = self.center_x + int((max_radius + 50) * math.cos(display_angle_rad))
            text_y = self.center_y - int((max_radius + 50) * math.sin(display_angle_rad))
            
            text = self.info_font.render(f"{angle}°", True, self.colors['angle_marks'])
            text_rect = text.get_rect(center=(text_x, text_y))
            self.screen.blit(text, text_rect)
    
    def draw_robot(self):
        """Draw robot at center"""
        pygame.draw.circle(self.screen, self.colors['robot'], 
                         (self.center_x, self.center_y), 20, 5)
        
        # Direction arrow
        arrow_length = 35
        end_x = self.center_x
        end_y = self.center_y - arrow_length
        pygame.draw.line(self.screen, self.colors['robot'], 
                       (self.center_x, self.center_y), (end_x, end_y), 8)
        
        # Robot dimensions
        robot_width_pixels = int(500 * self.display_scale / 1000)
        robot_length_pixels = int(650 * self.display_scale / 1000)
        
        robot_rect = pygame.Rect(
            self.center_x - robot_width_pixels // 2,
            self.center_y - robot_length_pixels // 2,
            robot_width_pixels,
            robot_length_pixels
        )
        pygame.draw.rect(self.screen, self.colors['robot'], robot_rect, 2)
    
    def draw_obstacles(self, obstacles):
        """Draw obstacles on the display with correct coordinate transformation"""
        if not obstacles:
            return 0
        
        drawn_count = 0
        for obstacle in obstacles:
            try:
                # Handle Position objects correctly
                if hasattr(obstacle, 'angle') and hasattr(obstacle, 'distance'):
                    # This is a Position object
                    angle_rad = obstacle.angle
                    distance = obstacle.distance
                elif isinstance(obstacle, (list, tuple)) and len(obstacle) >= 2:
                    # This is a (angle, distance) tuple - angle in degrees
                    angle_rad = math.radians(obstacle[0])
                    distance = obstacle[1]
                else:
                    continue
                
                # Convert distance to meters
                distance_m = distance / 1000.0
                
                # Filter by distance range
                if not (0.1 <= distance_m <= self.max_display_range):
                    continue
                
                # CORRECT coordinate transformation for pygame display
                # LiDAR angle 0° = robot forward (top of screen)
                # Convert to display coordinates where 0° is top, angles increase clockwise
                display_angle_rad = angle_rad - math.pi/2  # Rotate so 0° points up
                
                # Calculate screen coordinates
                x = self.center_x + int(distance_m * self.display_scale * math.cos(display_angle_rad))
                y = self.center_y + int(distance_m * self.display_scale * math.sin(display_angle_rad))
                
                # Check if point is within screen bounds
                if (50 <= x < self.screen_width - 50 and 50 <= y < self.screen_height - 50):
                    pygame.draw.circle(self.screen, self.colors['obstacles'], (x, y), 8)
                    pygame.draw.circle(self.screen, (100, 0, 0), (x, y), 12, 2)
                    drawn_count += 1
                    
            except Exception as e:
                continue
        
        return drawn_count
    
    def draw_target(self, target_position):
        """Draw target person"""
        if not target_position:
            return
            
        screen_coord = self.position_to_screen_coords(target_position)
        if screen_coord:
            self.draw_star(screen_coord, 25, self.colors['target'])
    
    def draw_star(self, center, size, color):
        """Draw star for person detection"""
        try:
            x, y = center
            points = []
            
            for i in range(10):
                angle = math.radians(i * 36 - 90)
                radius = size if i % 2 == 0 else size * 0.4
                
                point_x = x + radius * math.cos(angle)
                point_y = y + radius * math.sin(angle)
                points.append((int(point_x), int(point_y)))
            
            if len(points) >= 3:
                pygame.draw.polygon(self.screen, (100, 100, 0), points)
                pygame.draw.polygon(self.screen, color, points)
                pygame.draw.polygon(self.screen, (255, 255, 255), points, 3)
        except Exception:
            pygame.draw.circle(self.screen, color, center, size//2)
    
    def draw_path(self, path):
        """Draw navigation path"""
        if not path or len(path) < 2:
            return
        
        screen_points = []
        for position in path:
            screen_coord = self.position_to_screen_coords(position)
            if screen_coord:
                screen_points.append(screen_coord)
        
        if len(screen_points) >= 2:
            # Draw path lines
            for i in range(len(screen_points) - 1):
                pygame.draw.line(self.screen, self.colors['path_color'], 
                               screen_points[i], screen_points[i + 1], 6)
            
            # Draw waypoints
            for i, point in enumerate(screen_points):
                if i == 0:
                    pygame.draw.circle(self.screen, self.colors['waypoint_color'], point, 15)
                    pygame.draw.circle(self.screen, (0, 255, 0), point, 8)
                elif i == len(screen_points) - 1:
                    pygame.draw.circle(self.screen, self.colors['waypoint_color'], point, 15)
                    pygame.draw.circle(self.screen, (255, 0, 0), point, 8)
                else:
                    pygame.draw.circle(self.screen, self.colors['waypoint_color'], point, 10)
                    pygame.draw.circle(self.screen, self.colors['path_color'], point, 6)
    
    def draw_status(self, obstacle_count, status_info, exit_requested):
        """Draw status information"""
        # Title
        title = self.font.render("MAXINE LIDAR CHASE", True, self.colors['text'])
        title_rect = title.get_rect(center=(self.screen_width // 2, 50))
        self.screen.blit(title, title_rect)
        
        # Exit instruction
        exit_color = self.colors['status_danger'] if exit_requested else self.colors['status_warning']
        exit_text = self.info_font.render("Press ESC to exit", True, exit_color)
        exit_rect = exit_text.get_rect(center=(self.screen_width // 2, 90))
        self.screen.blit(exit_text, exit_rect)
        
        # Status panel
        info_x = self.screen_width - 400
        y_offset = 150
        
        # Obstacle status
        obstacle_status = f"Obstacles: {obstacle_count}"
        obstacle_color = self.colors['status_good'] if obstacle_count > 0 else self.colors['status_warning']
        obstacle_text = self.info_font.render(obstacle_status, True, obstacle_color)
        self.screen.blit(obstacle_text, (info_x, y_offset))
        y_offset += 50
        
        # Additional status info
        if status_info:
            for key, value in status_info.items():
                if isinstance(value, (int, float, str)):
                    status_line = f"{key}: {value}"
                    status_text = self.small_font.render(status_line, True, self.colors['text'])
                    self.screen.blit(status_text, (info_x, y_offset))
                    y_offset += 35
    
    def position_to_screen_coords(self, position):
        """Convert position to screen coordinates with correct transformation"""
        if not position:
            return None
        
        # Get angle and distance from Position object
        if hasattr(position, 'angle') and hasattr(position, 'distance'):
            angle_rad = position.angle
            distance = position.distance
        else:
            return None
        
        if distance <= 0:
            return None
        
        # Convert distance to meters
        distance_m = distance / 1000.0
        if distance_m > self.max_display_range:
            return None
        
        # CORRECT coordinate transformation matching draw_obstacles
        display_angle_rad = angle_rad - math.pi/2  # Rotate so 0° points up
        
        x = self.center_x + int(distance_m * self.display_scale * math.cos(display_angle_rad))
        y = self.center_y + int(distance_m * self.display_scale * math.sin(display_angle_rad))
        
        return (x, y)
    
    def render_frame(self, obstacles, target_position=None, path=None, status_info=None, exit_requested=False):
        """Render complete frame"""
        try:
            # Clear screen
            self.screen.fill(self.colors['background'])
            
            # Draw all elements
            self.draw_grid()
            self.draw_robot()
            
            obstacle_count = self.draw_obstacles(obstacles)
            
            if path:
                self.draw_path(path)
            
            if target_position:
                self.draw_target(target_position)
            
            self.draw_status(obstacle_count, status_info, exit_requested)
            
            # Update display
            pygame.display.flip()
                
        except Exception as e:
            print(f"❌ Render error: {e}")
    
    def cleanup(self):
        """Clean up renderer"""
        try:
            self.screen.fill((0, 0, 0))
            pygame.display.flip()
        except Exception:
            pass


class LidarChaseBehavior(MaxineBehavior):
    """
    Complete LiDAR Chase Behavior with pygame display
    """
    
    def __init__(self):
        super().__init__("LiDAR Chase Behavior")
        
        # Blackboard keys
        self.blackboard.register_key("TARGET_PERSON", access=py_trees.common.Access.READ)
        self.blackboard.register_key("PATH", access=py_trees.common.Access.WRITE)
        
        # System components
        self.lidar_system = None
        self.renderer = None
        self.current_state = LidarChaseState.INITIALIZING
        
        # Exit handling
        self.exit_requested = False
        self.exit_confirmed = False
        self.exit_start_time = 0
        self.exit_timeout = 2.0
        
        # Navigation state
        self.current_path = []
        self.target_position = None
        self.last_pathfinding_time = 0
        self.pathfinding_interval = 1.0
        
        # Performance tracking
        self.update_count = 0
        self.last_status_time = 0
        
        # Threading for pathfinding
        self.path_thread = None
        self.path_lock = threading.Lock()
        self.pathfinding_active = False
    
    def initialize_systems(self):
        """Initialize LiDAR and rendering systems"""
        try:
            robot = self.get_robot()
            
            # Initialize LiDAR system
            if not self.lidar_system:
                self.lidar_system = WorkingLidarSystem(robot)
                
                if self.lidar_system.start():
                    time.sleep(2.0)  # Allow stabilization
                    print("✅ LiDAR system started - stabilizing for 4 seconds...")
                else:
                    print("❌ Failed to initialize LiDAR system")
                    self.current_state = LidarChaseState.ERROR
                    return False
            
            # Initialize renderer
            if not self.renderer:
                self.renderer = PygameLidarRenderer()
            
            self.current_state = LidarChaseState.SCANNING
            return True
            
        except Exception as e:
            print(f"❌ System initialization error: {e}")
            self.current_state = LidarChaseState.ERROR
            return False
    
    def handle_pygame_events(self):
        """Handle pygame events"""
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if not self.exit_requested:
                        self.exit_requested = True
                        self.exit_start_time = time.time()
                        self.current_state = LidarChaseState.EXITING
                    return True  # Exit requested
            elif event.type == pygame.QUIT:
                self.exit_requested = True
                self.current_state = LidarChaseState.EXITING
                return True
        
        return False
    
    def update_person_detection(self):
        """Update person detection from camera"""
        try:
            target_person: dai.SpatialImgDetection = self.blackboard.get("TARGET_PERSON")
            
            if target_person:
                spatial_coords = getattr(target_person, 'spatialCoordinates', None)
                if spatial_coords is None:
                    self.target_position = None
                    self.current_state = LidarChaseState.SCANNING
                    return False
                
                x_camera = getattr(spatial_coords, 'x', 0)
                z_camera = getattr(spatial_coords, 'z', 1000)
                
                if z_camera <= 0:
                    z_camera = 1000
                
                angle_rad = math.atan2(x_camera, z_camera)
                distance = max(100, z_camera - 300)
                
                self.target_position = Position(angle=angle_rad, distance=distance)
                
                if distance < 500:  # 50cm threshold
                    self.current_state = LidarChaseState.TARGET_REACHED
                else:
                    self.current_state = LidarChaseState.PERSON_DETECTED
                
                return True
            else:
                self.target_position = None
                self.current_state = LidarChaseState.SCANNING
                return False
                
        except KeyError:
            self.target_position = None
            self.current_state = LidarChaseState.SCANNING
            return False
        except Exception:
            self.target_position = None
            self.current_state = LidarChaseState.SCANNING
            return False
    
    def update_pathfinding(self):
        """Update pathfinding with threading"""
        if not self.target_position:
            return
        
        current_time = time.time()
        
        if (current_time - self.last_pathfinding_time > self.pathfinding_interval and 
            not self.pathfinding_active):
            
            # Get obstacles as Position objects
            obstacles = []
            if self.lidar_system:
                lidar_obstacles = self.lidar_system.get_latest_obstacles()
                # lidar_obstacles are already Position objects, use them directly
                obstacles = lidar_obstacles if lidar_obstacles else []
            
            # Start pathfinding in thread
            with self.path_lock:
                self.pathfinding_active = True
            
            self.path_thread = threading.Thread(
                target=self._calculate_path_threaded,
                args=(self.target_position, obstacles),
                daemon=True
            )
            self.path_thread.start()
            
            self.last_pathfinding_time = current_time
    
    def _calculate_path_threaded(self, target_position, obstacles):
        """Calculate path in separate thread"""
        try:
            path, debug_info = a_star(obstacles, target_position)
            
            with self.path_lock:
                self.current_path = path if path else []
                self.pathfinding_active = False
                
                # Update blackboard
                self.blackboard.set("PATH", self.current_path)
                
                if self.current_path:
                    self.current_state = LidarChaseState.NAVIGATING
                
        except Exception as e:
            with self.path_lock:
                self.pathfinding_active = False
    
    def execute_movement(self):
        """Execute movement based on current path"""
        if not self.current_path or self.current_state != LidarChaseState.NAVIGATING:
            self._stop_robot()
            return
        
        try:
            # Simple path following - use first waypoint
            next_waypoint = self.current_path[0]
            
            if not hasattr(next_waypoint, 'angle') or not hasattr(next_waypoint, 'distance'):
                self._stop_robot()
                return
            
            angle = getattr(next_waypoint, 'angle', 0)
            distance = getattr(next_waypoint, 'distance', 1000)
            
            angle_deg = math.degrees(angle)
            
            # Normalize angle
            while angle_deg > 180:
                angle_deg -= 360
            while angle_deg < -180:
                angle_deg += 360
            
            # Check if waypoint reached
            if distance < 600:  # Waypoint reached
                self.current_path.pop(0)
                if not self.current_path:
                    self.current_state = LidarChaseState.SCANNING
                return
            
            # Calculate movement direction and speed
            if -15 <= angle_deg <= 15:
                direction = MovementDirection.FORWARDS
                speed = 1.0
            elif 15 < angle_deg <= 45:
                direction = MovementDirection.FORWARDS_RIGHT
                speed = 0.8
            elif -45 <= angle_deg < -15:
                direction = MovementDirection.FORWARDS_LEFT
                speed = 0.8
            elif 45 < angle_deg <= 135:
                direction = MovementDirection.RIGHT
                speed = 0.6
            elif -135 <= angle_deg < -45:
                direction = MovementDirection.LEFT
                speed = 0.6
            else:
                direction = MovementDirection.RIGHT if angle_deg > 0 else MovementDirection.LEFT
                speed = 0.5
            
            # Execute movement
            robot = self.get_robot()
            if robot.velocity_manager:
                movement_config = VelocityConfig(direction, speed)
                robot.velocity_manager.perform_action(movement_config)
                
        except Exception as e:
            self._stop_robot()
    
    def _stop_robot(self):
        """Stop robot movement"""
        try:
            robot = self.get_robot()
            if robot.velocity_manager:
                stop_config = VelocityConfig(MovementDirection.NONE, 0)
                robot.velocity_manager.perform_action(stop_config)
        except Exception:
            pass
    
    def handle_target_reached(self):
        """Handle target reached state"""
        self._stop_robot()
        
        # Announce success
        try:
            robot = self.get_robot()
            if robot.speech_manager:
                robot.speech_manager.perform_action("Person reached!")
        except Exception:
            pass
        
        self.exit_requested = True
        self.current_state = LidarChaseState.EXITING
    
    def perform_cleanup(self):
        """Cleanup all systems"""
        try:
            # Stop robot movement
            self._stop_robot()
            
            # Stop pathfinding thread
            with self.path_lock:
                self.pathfinding_active = False
            
            if self.path_thread and self.path_thread.is_alive():
                self.path_thread.join(timeout=1.0)
            
            # Stop LiDAR system
            if self.lidar_system:
                self.lidar_system.stop()
                self.lidar_system = None
            
            # Clean up renderer
            if self.renderer:
                self.renderer.cleanup()
                self.renderer = None
            
            # Clear blackboard
            self.blackboard.set("PATH", [])
            
            # Clear pygame events
            pygame.event.clear()
            
        except Exception as e:
            print(f"❌ Cleanup error: {e}")
    
    def update(self) -> Status:
        """Main update loop"""
        try:
            self.update_count += 1
            
            # Handle pygame events
            try:
                exit_requested = self.handle_pygame_events()
            except Exception:
                exit_requested = False
            
            # Handle exit request
            if self.exit_requested or exit_requested:
                if not self.exit_confirmed:
                    current_time = time.time()
                    
                    # Show exit in progress
                    try:
                        if self.renderer:
                            obstacles = self.lidar_system.get_latest_obstacles() if self.lidar_system else []
                            status_info = {'State': 'EXITING...', 'Timer': f"{self.exit_timeout - (current_time - self.exit_start_time):.1f}s"}
                            self.renderer.render_frame(
                                obstacles, self.target_position, self.current_path, 
                                status_info, exit_requested=True
                            )
                    except Exception:
                        pass
                    
                    # Check timeout
                    if current_time - self.exit_start_time > self.exit_timeout:
                        self.exit_confirmed = True
                
                if self.exit_confirmed:
                    self.perform_cleanup()
                    robot = self.get_robot()
                    robot.set_mode(RobotMode.IDLE)
                    return Status.SUCCESS
                
                return Status.RUNNING
            
            # Initialize systems if needed
            if self.current_state == LidarChaseState.INITIALIZING:
                try:
                    if not self.initialize_systems():
                        return Status.FAILURE
                except Exception:
                    return Status.FAILURE
            
            # Handle error state
            if self.current_state == LidarChaseState.ERROR:
                return Status.FAILURE
            
            # Update person detection
            try:
                self.update_person_detection()
            except Exception:
                self.current_state = LidarChaseState.SCANNING
            
            # Handle target reached
            if self.current_state == LidarChaseState.TARGET_REACHED:
                try:
                    self.handle_target_reached()
                except Exception:
                    pass
                return Status.RUNNING
            
            # Update pathfinding
            if self.current_state in [LidarChaseState.PERSON_DETECTED, LidarChaseState.NAVIGATING]:
                try:
                    self.update_pathfinding()
                except Exception:
                    pass
            
            # Execute movement
            if self.current_state == LidarChaseState.NAVIGATING:
                try:
                    self.execute_movement()
                except Exception:
                    self._stop_robot()
            else:
                self._stop_robot()
            
            # Render display
            try:
                if self.renderer and self.lidar_system:
                    obstacles = []
                    try:
                        obstacles = self.lidar_system.get_latest_obstacles()
                        if not isinstance(obstacles, list):
                            obstacles = []
                    except Exception:
                        obstacles = []
                    
                    target_distance = "None"
                    try:
                        if self.target_position:
                            distance_val = getattr(self.target_position, 'distance', 0)
                            if distance_val > 0:
                                target_distance = f"{distance_val:.0f}mm"
                    except Exception:
                        target_distance = "Error"
                    
                    status_info = {
                        'State': str(self.current_state.value),
                        'Obstacles': len(obstacles),
                        'Path_Points': len(self.current_path),
                        'Target_Distance': target_distance
                    }
                    
                    try:
                        self.renderer.render_frame(
                            obstacles, self.target_position, self.current_path, 
                            status_info, exit_requested=False
                        )
                    except Exception as render_error:
                        print(f"⚠️ Render error: {render_error}")
                        
            except Exception:
                pass
            
            return Status.RUNNING
            
        except Exception as e:
            print(f"❌ Critical system error: {e}")
            self.current_state = LidarChaseState.ERROR
            return Status.FAILURE
    
    def terminate(self, new_status: Status):
        """Clean termination"""
        self.perform_cleanup()
        super().terminate(new_status)