from typing import List, Dict, Optional
from .ObjectDetectionPipeline import ObjectDetectionPipeline
from .CameraReading import CameraReading
from py_trees.common import Status
import py_trees
import depthai as dai
import cv2
import numpy as np
import time
import math


class PersonTracker:
    """
    Ultra-fast person tracker - IMMEDIATE validation for real-time response
    """
    
    def __init__(self, detection: dai.SpatialImgDetection, frame_number: int):
        self.first_detection = detection
        self.latest_detection = detection
        self.frame_count = 1
        self.first_frame = frame_number
        self.last_frame = frame_number
        self.is_valid = True  # IMMEDIATE validation for speed
        
        # Calculate center for tracking
        self.center_x = (detection.xmin + detection.xmax) / 2
        self.center_y = (detection.ymin + detection.ymax) / 2
        
    def update(self, detection: dai.SpatialImgDetection, frame_number: int) -> bool:
        """
        Update tracker with new detection. Returns True if this detection belongs to this tracker
        """
        # Calculate new center
        new_center_x = (detection.xmin + detection.xmax) / 2
        new_center_y = (detection.ymin + detection.ymax) / 2
        
        # Check if this detection is close enough to be the same person
        distance = math.sqrt((new_center_x - self.center_x)**2 + (new_center_y - self.center_y)**2)
        
        # Allow for some movement (10% of image width/height)
        threshold = 0.1
        
        if distance < threshold and frame_number == self.last_frame + 1:
            # This is likely the same person in the next frame
            self.latest_detection = detection
            self.frame_count += 1
            self.last_frame = frame_number
            
            # Update center (simple average for speed)
            self.center_x = (self.center_x + new_center_x) / 2
            self.center_y = (self.center_y + new_center_y) / 2
            
            # Already valid from frame 1 for immediate response
            return True
                
            return True
        
        return False
    
    def is_expired(self, current_frame: int, max_gap: int = 5) -> bool:
        """
        Check if this tracker has expired (no updates for too long)
        """
        return current_frame - self.last_frame > max_gap


class ObjectDetectionReading(CameraReading):
    """
    Camera reading from Object Detection Camera mode with dual mono cameras and person tracking
    """

    IMAGE_KEY = ObjectDetectionPipeline.ObjectDetectionQueues.IMAGE_OUT

    LABEL_MAP = [
        "background",
        "aeroplane",
        "bicycle",
        "bird",
        "boat",
        "bottle",
        "bus",
        "car",
        "cat",
        "chair",
        "cow",
        "diningtable",
        "dog",
        "horse",
        "motorbike",
        "person",
        "pottedplant",
        "sheep",
        "sofa",
        "train",
        "tvmonitor",
    ]

    # Class variables for person tracking
    _person_trackers: List[PersonTracker] = []
    _frame_number: int = 0
    _last_cleanup: int = 0

    def __init__(self, queue_readings):
        super().__init__(queue_readings)
        # Set confidence threshold to 65% as requested
        self.confidence_threshold = 0.65
        self.distance_range = (300, 15000)       # 30cm to 15m for long range detection
        self.min_box_size = (0.01, 0.02)        # Smaller minimum size for distant persons
        self.max_box_size = (0.9, 0.9)          # Maximum reasonable size
        self.aspect_ratio_range = (0.4, 10.0)   # Wider aspect ratio range for distant detection
        
        # Increment frame number for tracking
        ObjectDetectionReading._frame_number += 1
        
        # Clean up old trackers every 60 frames (reduced frequency)
        if ObjectDetectionReading._frame_number - ObjectDetectionReading._last_cleanup > 60:
            self._cleanup_expired_trackers()
            ObjectDetectionReading._last_cleanup = ObjectDetectionReading._frame_number

    def _cleanup_expired_trackers(self):
        """Remove expired person trackers"""
        ObjectDetectionReading._person_trackers = [
            tracker for tracker in ObjectDetectionReading._person_trackers 
            if not tracker.is_expired(ObjectDetectionReading._frame_number)
        ]

    def get_people_locations(self) -> List[dai.SpatialImgDetection]:
        """
        Get filtered people locations with 10-frame validation tracking
        """
        objects = self.queue_readings[
            ObjectDetectionPipeline.ObjectDetectionQueues.OBJECT_OUT
        ]
        
        if not objects or not hasattr(objects, 'detections'):
            return []

        # First filter: get all person detections that meet our quality standards
        raw_people = []
        for detection in objects.detections:
            if (detection.label == self.LABEL_MAP.index("person") and 
                detection.confidence >= self.confidence_threshold):
                raw_people.append(detection)

        if not raw_people:
            return []

        # Apply quality filters
        filtered_people = self.apply_quality_filters(raw_people)
        
        if not filtered_people:
            return []

        # Update person trackers with new detections
        self._update_person_trackers(filtered_people)
        
        # Return only validated persons (with 10+ consecutive frames)
        validated_people = []
        for tracker in ObjectDetectionReading._person_trackers:
            if tracker.is_valid:
                validated_people.append(tracker.latest_detection)
        
        # Return the closest validated person if any
        if validated_people:
            closest_person = self.get_closest_person(validated_people)
            return [closest_person] if closest_person else []
        
        return []

    def _update_person_trackers(self, detections: List[dai.SpatialImgDetection]):
        """
        Update person trackers with new detections
        """
        current_frame = ObjectDetectionReading._frame_number
        unmatched_detections = detections.copy()
        
        # Try to match detections to existing trackers
        for tracker in ObjectDetectionReading._person_trackers:
            for detection in unmatched_detections:
                if tracker.update(detection, current_frame):
                    unmatched_detections.remove(detection)
                    break
        
        # Create new trackers for unmatched detections
        for detection in unmatched_detections:
            new_tracker = PersonTracker(detection, current_frame)
            ObjectDetectionReading._person_trackers.append(new_tracker)

    def apply_quality_filters(self, detections: List[dai.SpatialImgDetection]) -> List[dai.SpatialImgDetection]:
        """Apply quality filters with 65% confidence threshold"""
        filtered = []
        
        for detection in detections:
            try:
                # Confidence filter (65% minimum)
                if detection.confidence < self.confidence_threshold:
                    continue
                
                # Distance filter
                if hasattr(detection, 'spatialCoordinates'):
                    z_dist = detection.spatialCoordinates.z
                    if z_dist < self.distance_range[0] or z_dist > self.distance_range[1]:
                        continue
                else:
                    continue
                
                # Bounding box size filter
                box_width = detection.xmax - detection.xmin
                box_height = detection.ymax - detection.ymin
                
                if (box_width < self.min_box_size[0] or 
                    box_height < self.min_box_size[1] or
                    box_width > self.max_box_size[0] or 
                    box_height > self.max_box_size[1]):
                    continue
                
                # Aspect ratio filter
                if box_width > 0:
                    aspect_ratio = box_height / box_width
                    if (aspect_ratio < self.aspect_ratio_range[0] or 
                        aspect_ratio > self.aspect_ratio_range[1]):
                        continue
                else:
                    continue
                
                filtered.append(detection)
                
            except Exception as e:
                continue
        
        return filtered

    def apply_nms(self, detections: List[dai.SpatialImgDetection], iou_threshold=0.3) -> List[dai.SpatialImgDetection]:
        """Apply Non-Maximum Suppression to remove overlapping detections"""
        if len(detections) <= 1:
            return detections
        
        # Sort by confidence (highest first)
        detections = sorted(detections, key=lambda x: x.confidence, reverse=True)
        
        kept_detections = []
        
        for current in detections:
            keep_current = True
            
            for kept in kept_detections:
                iou = self.calculate_iou(current, kept)
                if iou > iou_threshold:
                    keep_current = False
                    break
            
            if keep_current:
                kept_detections.append(current)
        
        return kept_detections

    def calculate_iou(self, det1: dai.SpatialImgDetection, det2: dai.SpatialImgDetection) -> float:
        """Calculate Intersection over Union (IoU) for two detections"""
        try:
            # Calculate intersection
            x1 = max(det1.xmin, det2.xmin)
            y1 = max(det1.ymin, det2.ymin)
            x2 = min(det1.xmax, det2.xmax)
            y2 = min(det1.ymax, det2.ymax)
            
            if x2 <= x1 or y2 <= y1:
                return 0.0
            
            intersection = (x2 - x1) * (y2 - y1)
            
            # Calculate union
            area1 = (det1.xmax - det1.xmin) * (det1.ymax - det1.ymin)
            area2 = (det2.xmax - det2.xmin) * (det2.ymax - det2.ymin)
            union = area1 + area2 - intersection
            
            if union <= 0:
                return 0.0
            
            return intersection / union
            
        except Exception as e:
            return 0.0

    def get_closest_person(self, detections: List[dai.SpatialImgDetection]) -> dai.SpatialImgDetection:
        """Get the person closest to the camera based on Z distance"""
        if not detections:
            return None
        
        closest_person = None
        min_distance = float('inf')
        
        for detection in detections:
            try:
                if hasattr(detection, 'spatialCoordinates'):
                    z_distance = detection.spatialCoordinates.z
                    if 0 < z_distance < min_distance:
                        min_distance = z_distance
                        closest_person = detection
            except Exception as e:
                continue
        
        return closest_person

    def get_object_locations(self) -> List[dai.SpatialImgDetection]:
        """Get all object detections with 65% confidence filtering"""
        objects = self.queue_readings[
            ObjectDetectionPipeline.ObjectDetectionQueues.OBJECT_OUT
        ]
        
        if not objects or not hasattr(objects, 'detections'):
            return []
            
        all_objects = []
        
        for obj in objects.detections:
            try:
                # Apply 65% confidence filter
                if obj.confidence >= self.confidence_threshold:
                    all_objects.append(obj)
                    
            except Exception as e:
                continue
                
        return all_objects

    def get_tracking_status(self) -> Dict:
        """Get current tracking status for debugging"""
        valid_trackers = [t for t in ObjectDetectionReading._person_trackers if t.is_valid]
        total_trackers = len(ObjectDetectionReading._person_trackers)
        
        return {
            'frame_number': ObjectDetectionReading._frame_number,
            'total_trackers': total_trackers,
            'valid_trackers': len(valid_trackers),
            'confidence_threshold': self.confidence_threshold * 100,
            'tracking_enabled': True
        }

    def get_frame(self):
        """
        Override the get_frame function by plotting bounding boxes with tracking information
        """
        base_frame = super().get_frame()
        
        if base_frame is None:
            return None

        def point_to_image_coord(x, y):
            return (np.array((x, y)).clip(0, 1) * base_frame.shape[:2]).astype(np.int32)

        objects = self.queue_readings[
            ObjectDetectionPipeline.ObjectDetectionQueues.OBJECT_OUT
        ]

        if not objects or not hasattr(objects, 'detections'):
            return base_frame

        # Show detections with different colors based on tracking status
        colors = {
            'person_valid': (0, 255, 0),      # Green for validated persons
            'person_tracking': (255, 255, 0), # Yellow for persons being tracked
            'person_new': (255, 165, 0),      # Orange for new person detections
            'other': (0, 0, 255)              # Blue for other objects
        }

        detection_count = 0
        for i, detection in enumerate(objects.detections):
            # Only show detections that pass the confidence threshold
            if detection.confidence >= self.confidence_threshold:
                
                # Determine color based on tracking status
                label = self.LABEL_MAP[detection.label] if detection.label < len(self.LABEL_MAP) else "unknown"
                
                if label == "person":
                    # Find corresponding tracker
                    tracker_status = "new"
                    for tracker in ObjectDetectionReading._person_trackers:
                        if tracker.latest_detection == detection:
                            if tracker.is_valid:
                                tracker_status = "valid"
                            else:
                                tracker_status = "tracking"
                            break
                    
                    color = colors[f'person_{tracker_status}']
                    thickness = 4 if tracker_status == "valid" else 2
                else:
                    color = colors['other']
                    thickness = 1
                
                detection_count += 1
                
                # Get bounding box coordinates
                start_point = point_to_image_coord(detection.xmin, detection.ymin)
                end_point = point_to_image_coord(detection.xmax, detection.ymax)

                # Build label text with tracking info
                confidence = detection.confidence
                
                # Add distance if available
                distance_text = ""
                if hasattr(detection, 'spatialCoordinates'):
                    distance_text = f" {detection.spatialCoordinates.z:.0f}mm"
                
                if label == "person":
                    text = f"{label} ({confidence:.2f}){distance_text} [{tracker_status}]"
                else:
                    text = f"{label} ({confidence:.2f}){distance_text}"

                # Add bounding box rectangle on image
                base_frame = cv2.rectangle(
                    base_frame,
                    start_point,
                    end_point,
                    color=color,
                    thickness=thickness,
                )

                # Add label on image
                base_frame = cv2.putText(
                    base_frame,
                    text,
                    start_point + np.array((0, -10)),
                    cv2.FONT_HERSHEY_TRIPLEX,
                    0.5,
                    color,
                    thickness=2 if label == "person" else 1
                )

        # Add tracking status info
        tracking_status = self.get_tracking_status()
        status_lines = [
            f"Frame: {tracking_status['frame_number']}",
            f"Confidence: {tracking_status['confidence_threshold']:.0f}%",
            f"Trackers: {tracking_status['valid_trackers']}/{tracking_status['total_trackers']}",
            f"Validated persons: {len(self.get_people_locations())}"
        ]
        
        y_offset = 30
        for line in status_lines:
            cv2.putText(base_frame, line, (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            y_offset += 25

        return base_frame