from typing import List
from .LoopingThread import LoopingThread
from pyrplidar import PyRPlidar
import time
import logging
from math import radians
from ..path_finding.Position import Position


class LidarSensorThread(LoopingThread):
    def __init__(
        self,
        obstacles: List[Position],
        ms_delay: int = 50,  # Increased default delay for stability
        scan_count: int = 750,
        max_scan_timeout: float = 2.0,  # Max time to wait for scan data
        min_quality_threshold: int = 10,
        min_distance_threshold: int = 40,
        max_distance_threshold: int = 12000,  # 12 meters max range
        connection_retries: int = 3,
    ) -> None:
        super().__init__(ms_delay)
        self.scan_count = scan_count 
        self.obstacles = obstacles
        self.max_scan_timeout = max_scan_timeout
        self.min_quality_threshold = min_quality_threshold
        self.min_distance_threshold = min_distance_threshold
        self.max_distance_threshold = max_distance_threshold
        self.connection_retries = connection_retries
        
        # Status tracking
        self.lidar = None
        self.scan_generator = None
        self.is_connected = False
        self.last_successful_scan = time.time()
        self.connection_attempts = 0
        self.total_scan_errors = 0
        self.consecutive_failed_scans = 0
        self.max_consecutive_failures = 5
        
        # Performance tracking
        self.scan_stats = {
            'total_scans': 0,
            'valid_points': 0,
            'filtered_quality': 0,
            'filtered_distance': 0,
            'last_scan_time': 0
        }
        
        # Setup logging
        self.logger = logging.getLogger(f"LidarSensorThread_{id(self)}")
        self.logger.setLevel(logging.INFO)

    def tick(self):
        """Main scanning loop with robust error handling"""
        if not self.is_connected:
            self.logger.warning("LiDAR not connected, attempting reconnection...")
            if not self._attempt_reconnection():
                return
        
        obstacles = []
        scan_start_time = time.time()
        points_collected = 0
        
        try:
            # Collect scan data with timeout protection
            for count, scan_result in enumerate(self.scan_generator):
                current_time = time.time()
                
                # Check for scan timeout
                if current_time - scan_start_time > self.max_scan_timeout:
                    self.logger.warning(f"Scan timeout after {self.max_scan_timeout}s, collected {points_collected} points")
                    break
                
                # Validate scan data
                if not self._is_valid_scan(scan_result):
                    continue
                
                # Apply quality filter
                if scan_result.quality < self.min_quality_threshold:
                    self.scan_stats['filtered_quality'] += 1
                    continue
                
                # Apply distance filters
                if (scan_result.distance <= self.min_distance_threshold or 
                    scan_result.distance >= self.max_distance_threshold):
                    self.scan_stats['filtered_distance'] += 1
                    continue
                
                # Valid obstacle detected
                try:
                    obstacle = Position(
                        angle=radians(scan_result.angle), 
                        distance=scan_result.distance
                    )
                    obstacles.append(obstacle)
                    points_collected += 1
                    
                except Exception as e:
                    self.logger.error(f"Error creating Position object: {e}")
                    continue
                
                # Check if we've collected enough points
                if count >= self.scan_count:
                    break
            
            # Update obstacle list atomically
            if obstacles:
                self.obstacles.clear()
                self.obstacles.extend(obstacles)
                self.last_successful_scan = time.time()
                self.consecutive_failed_scans = 0
                
                # Update statistics
                self.scan_stats['total_scans'] += 1
                self.scan_stats['valid_points'] += points_collected
                self.scan_stats['last_scan_time'] = time.time() - scan_start_time
                
                self.logger.debug(f"Collected {points_collected} valid obstacles in {self.scan_stats['last_scan_time']:.3f}s")
            else:
                self.consecutive_failed_scans += 1
                self.logger.warning(f"No valid obstacles found in scan (failure #{self.consecutive_failed_scans})")
        
        except Exception as e:
            self.total_scan_errors += 1
            self.consecutive_failed_scans += 1
            self.logger.error(f"Scan error #{self.total_scan_errors}: {e}")
            
            # Check if we need to reconnect
            if self.consecutive_failed_scans >= self.max_consecutive_failures:
                self.logger.error(f"Too many consecutive failures ({self.consecutive_failed_scans}), marking as disconnected")
                self.is_connected = False
    
    def _is_valid_scan(self, scan_result) -> bool:
        """Validate scan result data"""
        if not scan_result:
            return False
        
        # Check if scan_result has required attributes
        if not hasattr(scan_result, 'quality') or not hasattr(scan_result, 'distance') or not hasattr(scan_result, 'angle'):
            return False
        
        # Check for reasonable values
        if scan_result.quality < 0 or scan_result.distance < 0:
            return False
        
        # Check angle is in valid range (0-360)
        if scan_result.angle < 0 or scan_result.angle > 360:
            return False
        
        return True

    def _attempt_reconnection(self) -> bool:
        """Attempt to reconnect to LiDAR with retries"""
        if self.connection_attempts >= self.connection_retries:
            self.logger.error(f"Max reconnection attempts ({self.connection_retries}) reached")
            return False
        
        self.connection_attempts += 1
        self.logger.info(f"Reconnection attempt {self.connection_attempts}/{self.connection_retries}")
        
        try:
            # Clean up existing connection
            if self.lidar:
                try:
                    self.lidar.stop()
                    self.lidar.set_motor_pwm(0)
                    self.lidar.disconnect()
                except:
                    pass
                time.sleep(1)
            
            # Attempt new connection
            self.lidar = PyRPlidar()
            self.lidar.connect(port="/dev/ttyUSB0", baudrate=256000, timeout=3)
            
            # Test connection with device info
            try:
                # Try to get device info to verify connection
                info = self.lidar.get_info()
                health = self.lidar.get_health()
                self.logger.info(f"LiDAR reconnected - Model: {info.get('model', 'Unknown')}, Health: {health}")
            except Exception as e:
                self.logger.warning(f"Connected but could not get device info: {e}")
            
            # Start motor with gradual ramp-up
            self.lidar.set_motor_pwm(0)
            time.sleep(0.5)
            self.lidar.set_motor_pwm(400)
            time.sleep(2)  # Give motor time to stabilize
            
            # Initialize scan generator
            self.scan_generator = self.lidar.force_scan()
            
            self.is_connected = True
            self.connection_attempts = 0  # Reset counter on success
            self.consecutive_failed_scans = 0
            self.logger.info("LiDAR reconnection successful")
            return True
            
        except Exception as e:
            self.logger.error(f"Reconnection attempt {self.connection_attempts} failed: {e}")
            time.sleep(2)  # Wait before next attempt
            return False

    def on_start(self):
        """Initialize LiDAR connection with robust error handling"""
        self.logger.info("Starting LiDAR sensor thread...")
        
        try:
            self.lidar = PyRPlidar()
            self.lidar.connect(port="/dev/ttyUSB0", baudrate=256000, timeout=3)
            
            # Get device information for logging
            try:
                info = self.lidar.get_info()
                health = self.lidar.get_health()
                self.logger.info(f"LiDAR connected - Model: {info.get('model', 'Unknown')}, "
                               f"Firmware: {info.get('firmware', 'Unknown')}, "
                               f"Health: {health}")
            except Exception as e:
                self.logger.warning(f"Connected but device info unavailable: {e}")
            
            # Start motor with proper initialization sequence
            self.logger.info("Initializing LiDAR motor...")
            self.lidar.set_motor_pwm(0)  # Ensure motor is stopped
            time.sleep(0.5)
            self.lidar.set_motor_pwm(400)  # Start motor at optimal speed for A3
            time.sleep(2)  # Allow motor to reach stable speed
            
            # Initialize scanning
            self.scan_generator = self.lidar.force_scan()
            self.is_connected = True
            self.connection_attempts = 0
            
            self.logger.info("LiDAR sensor thread started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize LiDAR: {e}")
            self.is_connected = False
            # Don't raise exception - let the tick() method handle reconnection
    
    def on_finish(self):
        """Clean shutdown of LiDAR with proper error handling"""
        self.logger.info("Shutting down LiDAR sensor thread...")
        
        if self.lidar:
            try:
                # Stop scanning
                self.lidar.stop()
                self.logger.debug("LiDAR scanning stopped")
                
                # Stop motor gradually
                self.lidar.set_motor_pwm(0)
                time.sleep(1)  # Allow motor to spin down
                self.logger.debug("LiDAR motor stopped")
                
                # Disconnect
                self.lidar.disconnect()
                self.logger.debug("LiDAR disconnected")
                
            except Exception as e:
                self.logger.error(f"Error during LiDAR shutdown: {e}")
            
            finally:
                self.lidar = None
                self.scan_generator = None
                self.is_connected = False
        
        # Log final statistics
        self.logger.info(f"LiDAR session stats - Total scans: {self.scan_stats['total_scans']}, "
                        f"Valid points: {self.scan_stats['valid_points']}, "
                        f"Scan errors: {self.total_scan_errors}, "
                        f"Quality filtered: {self.scan_stats['filtered_quality']}, "
                        f"Distance filtered: {self.scan_stats['filtered_distance']}")
        
        self.logger.info("LiDAR sensor thread shutdown complete")
    
    def get_status(self) -> dict:
        """Get current LiDAR status for monitoring"""
        return {
            'connected': self.is_connected,
            'last_scan_age': time.time() - self.last_successful_scan,
            'total_obstacles': len(self.obstacles),
            'scan_stats': self.scan_stats.copy(),
            'error_count': self.total_scan_errors,
            'consecutive_failures': self.consecutive_failed_scans
        }
    
    def is_healthy(self) -> bool:
        """Check if LiDAR is operating normally"""
        if not self.is_connected:
            return False
        
        # Check if we've had a successful scan recently
        time_since_last_scan = time.time() - self.last_successful_scan
        if time_since_last_scan > 5.0:  # No successful scan in 5 seconds
            return False
        
        # Check for too many consecutive failures
        if self.consecutive_failed_scans >= self.max_consecutive_failures:
            return False
        
        return True