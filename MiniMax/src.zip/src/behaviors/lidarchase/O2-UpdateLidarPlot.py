import matplotlib
from math import radians
from src.path_finding.LidarPlot import LidarPlot
from src.path_finding.Position import Position

# Use TkAgg backend for better performance and compatibility
matplotlib.use("TkAgg")

from matplotlib import pyplot as plt
from src.behaviors.MaxineBehavior import MaxineBehavior
from py_trees.common import Status
import depthai as dai
import py_trees


class UpdateLidarPlot(MaxineBehavior):
    """
    Optimized LiDAR plot update behavior using the new balanced performance system
    """
    
    def __init__(self):
        """Initialize the optimized behavior"""
        super().__init__("optimized lidar plot")

        # Register blackboard keys
        self.blackboard.register_key(
            "TARGET_PERSON", access=py_trees.common.Access.WRITE
        )
        self.blackboard.register_key("PATH", access=py_trees.common.Access.WRITE)
        self.blackboard.register_key("LIDAR_PLOT", access=py_trees.common.Access.WRITE)
        
        # Performance monitoring
        self.update_count = 0
        self.last_performance_report = None

    def get_target_x_center(self) -> float:
        """
        Returns the middle of the current target's x axis coordinate
        """
        target_person: dai.SpatialImgDetection = self.blackboard.get("TARGET_PERSON")
        x_diff = target_person.xmax - target_person.xmin
        return target_person.xmin + (x_diff / 2)

    def get_or_create_lidar_plot(self):
        """Get existing plot or create new optimized plot"""
        # Check if plot already exists and is still valid
        if self.blackboard.exists("LIDAR_PLOT"):
            existing_plot = self.blackboard.get("LIDAR_PLOT")
            
            # Check if the plot is still active (window not closed)
            if hasattr(existing_plot, 'shutdown_requested') and not existing_plot.shutdown_requested:
                return existing_plot
            else:
                # Plot was closed, clean up and create new one
                try:
                    existing_plot.close()
                except:
                    pass

        # Create new optimized plot
        lidar_plot = LidarPlot(range_mm=7000, debug_algo_path=False)
        
        self.blackboard.set("LIDAR_PLOT", lidar_plot)
        print("Created new optimized LiDAR plot")
        return lidar_plot

    def calculate_target_position(self, target_person: dai.SpatialImgDetection) -> Position:
        """
        Calculate target position from camera detection data
        Enhanced for better accuracy
        """
        try:
            # Get distance (subtract offset for robot geometry)
            distance = target_person.spatialCoordinates.z - 650
            
            # Ensure minimum distance to avoid division by zero
            distance = max(distance, 100)
            
            # Get horizontal center of target
            x_center = self.get_target_x_center()
            
            # Convert camera coordinates to angle
            # Assuming camera FOV of 63.5 degrees horizontally
            angle = radians((x_center * 2 - 1) * 63.5)
            
            return Position(angle=angle, distance=distance)
            
        except Exception as e:
            print(f"Error calculating target position: {e}")
            return None

    def update(self) -> Status:
        """
        Main update loop - optimized for performance
        """
        try:
            # Get or create the optimized plot
            lidar_plot = self.get_or_create_lidar_plot()
            
            # Check if plot was closed by user
            if hasattr(lidar_plot, 'shutdown_requested') and lidar_plot.shutdown_requested:
                print("LiDAR plot was closed by user")
                return Status.FAILURE

            # Get robot and LiDAR data
            robot = self.get_robot()
            
            # Check if LiDAR sensor is available
            if robot.lidar_sensor is None:
                print("LiDAR sensor not available")
                return Status.FAILURE
            
            # Get obstacle readings from optimized sensor
            readings = robot.lidar_sensor.get_reading()
            
            # Plot obstacles using optimized system
            lidar_plot.plot_obstacles(readings)

            # Plot target person (red star) if available
            try:
                target_person: dai.SpatialImgDetection = self.blackboard.get("TARGET_PERSON")
                target_position = self.calculate_target_position(target_person)
                
                if target_position:
                    lidar_plot.plot_destination(target_position)
                    
            except KeyError:
                # No target person - clear destination
                lidar_plot.plot_destination(None)
            except Exception as e:
                print(f"Error plotting target person: {e}")

            # Plot navigation path if available
            try:
                path = self.blackboard.get("PATH")
                if path and isinstance(path, list) and len(path) > 0:
                    lidar_plot.plot_path(path)
                else:
                    lidar_plot.plot_path([])
                    
            except KeyError:
                # No path available - clear path
                lidar_plot.plot_path([])
            except Exception as e:
                print(f"Error plotting path: {e}")

            # Update the optimized plot
            lidar_plot.update_plot()
            
            # Performance monitoring
            self.update_count += 1
            if self.update_count % 50 == 0:  # Report every 50 updates
                print(f"LiDAR plot updated {self.update_count} times, {len(readings)} obstacles")
            
            return Status.SUCCESS
            
        except Exception as e:
            print(f"Error in UpdateLidarPlot: {e}")
            return Status.FAILURE

    def terminate(self, new_status: Status):
        """
        Clean up when behavior terminates
        """
        try:
            if self.blackboard.exists("LIDAR_PLOT"):
                lidar_plot = self.blackboard.get("LIDAR_PLOT")
                if hasattr(lidar_plot, 'close'):
                    lidar_plot.close()
                    print("LiDAR plot cleaned up on behavior termination")
        except Exception as e:
            print(f"Error cleaning up LiDAR plot: {e}")
        
        super().terminate(new_status)