import math

class Position:
    """
    Represents a position in polar coordinates (angle, distance)
    Used for lidar obstacle detection
    """
    
    def __init__(self, angle: float = 0.0, distance: float = 0.0):
        """
        Initialize position with angle and distance
        
        Args:
            angle: Angle in radians
            distance: Distance in millimeters
        """
        self.angle = angle
        self.distance = distance
    
    def to_cartesian(self):
        """
        Convert polar coordinates to cartesian coordinates
        
        Returns:
            tuple: (x, y) coordinates in millimeters
        """
        x = self.distance * math.cos(self.angle)
        y = self.distance * math.sin(self.angle)
        return (x, y)
    
    def __str__(self):
        """String representation of the position"""
        angle_deg = math.degrees(self.angle)
        return f"Position(angle={angle_deg:.1f}°, distance={self.distance:.1f}mm)"
    
    def __repr__(self):
        """Detailed string representation"""
        return self.__str__()