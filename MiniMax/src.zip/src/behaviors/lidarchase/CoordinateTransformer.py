import math
import numpy as np
from typing import Tuple, List, Optional
from src.path_finding.Position import Position


class CoordinateTransformer:
    """
    Handles coordinate transformations between different reference frames:
    - Camera coordinates (Oak-D camera)
    - LiDAR coordinates (RPLidar A3)
    - Robot coordinates (robot center/base)
    - World coordinates (fixed reference frame)
    
    Accounts for sensor positions and robot movement
    """
    
    def __init__(self):
        # Robot physical dimensions (mm)
        self.robot_length = 650
        self.robot_width = 500
        
        # Sensor positions relative to robot center (mm)
        # LiDAR position: front-center of robot base
        self.lidar_x_offset = self.robot_length / 2  # Front of robot
        self.lidar_y_offset = 0                      # Center width
        self.lidar_z_offset = 0                      # Base level
        
        # Camera position: top of head, set back from front
        self.camera_x_offset = (self.robot_length / 2) - 200  # 20cm back from front
        self.camera_y_offset = 0                               # Center width  
        self.camera_z_offset = 500                             # 50cm above base
        
        # Robot state tracking
        self.robot_position = Position(angle=0.0, distance=0.0)  # Robot position in world
        self.robot_heading = 0.0  # Robot heading in radians
        self.head_angle = 0.0     # Head angle relative to robot body
        
        # Movement tracking for coordinate updates
        self.last_update_time = 0
        self.movement_accumulator = Position(angle=0.0, distance=0.0)
    
    def set_robot_state(self, position: Position, heading: float, head_angle: float = 0.0):
        """
        Update robot state for coordinate transformations
        
        Args:
            position: Robot position in world coordinates
            heading: Robot heading in radians (0 = forward)
            head_angle: Head angle in radians relative to robot body
        """
        self.robot_position = position
        self.robot_heading = heading
        self.head_angle = head_angle
    
    def camera_to_robot_coordinates(self, x_camera: float, z_camera: float, 
                                   head_angle_rad: float = None) -> Position:
        """
        Transform camera coordinates to robot-centered coordinates
        
        Args:
            x_camera: X coordinate from camera (mm, left/right)
            z_camera: Z coordinate from camera (mm, forward)
            head_angle_rad: Head angle in radians (uses current if None)
            
        Returns:
            Position relative to robot center
        """
        if head_angle_rad is None:
            head_angle_rad = self.head_angle
        
        try:
            # Camera's view angle relative to camera
            camera_angle = math.atan2(x_camera, z_camera) if z_camera > 0 else 0.0
            camera_distance = math.sqrt(x_camera**2 + z_camera**2)
            
            # Transform to robot coordinates accounting for head angle and camera position
            # Head angle rotates the camera's view direction
            robot_angle = camera_angle + head_angle_rad
            
            # Account for camera position offset from robot center
            # Camera is mounted above and behind robot center
            adjusted_distance = max(100, camera_distance - self.camera_x_offset)
            
            return Position(angle=robot_angle, distance=adjusted_distance)
            
        except Exception as e:
            return Position(angle=0.0, distance=1000.0)
    
    def lidar_to_robot_coordinates(self, lidar_position: Position) -> Position:
        """
        Transform LiDAR coordinates to robot-centered coordinates
        
        Args:
            lidar_position: Position from LiDAR sensor
            
        Returns:
            Position relative to robot center
        """
        try:
            # LiDAR is at front-center of robot, so minimal transformation needed
            # Just account for the forward offset
            
            # Convert to cartesian, apply offset, convert back
            x_lidar, y_lidar = lidar_position.to_cartesian()
            
            # Account for LiDAR position offset (LiDAR is at front of robot)
            x_robot = x_lidar 
            y_robot = y_lidar - self.lidar_x_offset  # Move back to robot center
            
            # Convert back to polar coordinates
            distance = math.sqrt(x_robot**2 + y_robot**2)
            angle = math.atan2(x_robot, y_robot) if y_robot != 0 else 0.0
            
            return Position(angle=angle, distance=distance)
            
        except Exception as e:
            return lidar_position  # Return original if transformation fails
    
    def robot_to_world_coordinates(self, robot_position: Position) -> Position:
        """
        Transform robot-relative coordinates to world coordinates
        
        Args:
            robot_position: Position relative to robot center
            
        Returns:
            Position in world coordinates
        """
        try:
            # Convert robot-relative position to cartesian
            x_rel, y_rel = robot_position.to_cartesian()
            
            # Rotate by robot heading
            cos_h = math.cos(self.robot_heading)
            sin_h = math.sin(self.robot_heading)
            
            x_world = x_rel * cos_h - y_rel * sin_h
            y_world = x_rel * sin_h + y_rel * cos_h
            
            # Translate by robot world position
            robot_x, robot_y = self.robot_position.to_cartesian()
            x_world += robot_x
            y_world += robot_y
            
            # Convert back to polar
            distance = math.sqrt(x_world**2 + y_world**2)
            angle = math.atan2(x_world, y_world) if y_world != 0 else 0.0
            
            return Position(angle=angle, distance=distance)
            
        except Exception as e:
            return robot_position
    
    def world_to_robot_coordinates(self, world_position: Position) -> Position:
        """
        Transform world coordinates to robot-relative coordinates
        
        Args:
            world_position: Position in world coordinates
            
        Returns:
            Position relative to robot center
        """
        try:
            # Convert to cartesian
            x_world, y_world = world_position.to_cartesian()
            
            # Translate by robot position
            robot_x, robot_y = self.robot_position.to_cartesian()
            x_rel = x_world - robot_x
            y_rel = y_world - robot_y
            
            # Rotate by negative robot heading
            cos_h = math.cos(-self.robot_heading)
            sin_h = math.sin(-self.robot_heading)
            
            x_robot = x_rel * cos_h - y_rel * sin_h
            y_robot = x_rel * sin_h + y_rel * cos_h
            
            # Convert back to polar
            distance = math.sqrt(x_robot**2 + y_robot**2)
            angle = math.atan2(x_robot, y_robot) if y_robot != 0 else 0.0
            
            return Position(angle=angle, distance=distance)
            
        except Exception as e:
            return world_position
    
    def transform_obstacle_list(self, obstacles: List[Position], 
                               from_frame: str, to_frame: str) -> List[Position]:
        """
        Transform a list of obstacle positions between coordinate frames
        
        Args:
            obstacles: List of Position objects
            from_frame: Source frame ('lidar', 'robot', 'world')
            to_frame: Target frame ('lidar', 'robot', 'world')
            
        Returns:
            List of transformed positions
        """
        transformed = []
        
        for obstacle in obstacles:
            try:
                if from_frame == 'lidar' and to_frame == 'robot':
                    transformed_pos = self.lidar_to_robot_coordinates(obstacle)
                elif from_frame == 'robot' and to_frame == 'world':
                    transformed_pos = self.robot_to_world_coordinates(obstacle)
                elif from_frame == 'world' and to_frame == 'robot':
                    transformed_pos = self.world_to_robot_coordinates(obstacle)
                elif from_frame == to_frame:
                    transformed_pos = obstacle  # No transformation needed
                else:
                    # Chain transformations for other combinations
                    if from_frame == 'lidar' and to_frame == 'world':
                        robot_pos = self.lidar_to_robot_coordinates(obstacle)
                        transformed_pos = self.robot_to_world_coordinates(robot_pos)
                    elif from_frame == 'world' and to_frame == 'lidar':
                        robot_pos = self.world_to_robot_coordinates(obstacle)
                        # Inverse of lidar_to_robot
                        transformed_pos = robot_pos  # Simplified
                    else:
                        transformed_pos = obstacle
                
                transformed.append(transformed_pos)
                
            except Exception as e:
                # Keep original position if transformation fails
                transformed.append(obstacle)
        
        return transformed
    
    def update_robot_movement(self, movement_direction: str, distance_moved: float):
        """
        Update robot position based on movement
        
        Args:
            movement_direction: Movement direction string
            distance_moved: Distance moved in mm
        """
        try:
            # Convert movement to heading change and distance
            if movement_direction == "FORWARDS":
                self.robot_heading += 0
                # Update position
                x, y = self.robot_position.to_cartesian()
                x += distance_moved * math.sin(self.robot_heading)
                y += distance_moved * math.cos(self.robot_heading)
                
            elif movement_direction == "BACKWARDS":
                x, y = self.robot_position.to_cartesian()
                x -= distance_moved * math.sin(self.robot_heading)
                y -= distance_moved * math.cos(self.robot_heading)
                
            elif movement_direction == "LEFT":
                self.robot_heading -= math.radians(5)  # Estimate turn rate
                
            elif movement_direction == "RIGHT":
                self.robot_heading += math.radians(5)  # Estimate turn rate
                
            elif movement_direction == "FORWARDS_LEFT":
                self.robot_heading -= math.radians(2)
                x, y = self.robot_position.to_cartesian()
                x += distance_moved * 0.7 * math.sin(self.robot_heading)
                y += distance_moved * 0.7 * math.cos(self.robot_heading)
                
            elif movement_direction == "FORWARDS_RIGHT":
                self.robot_heading += math.radians(2)
                x, y = self.robot_position.to_cartesian()
                x += distance_moved * 0.7 * math.sin(self.robot_heading)
                y += distance_moved * 0.7 * math.cos(self.robot_heading)
            
            # Update robot position
            if 'x' in locals() and 'y' in locals():
                distance = math.sqrt(x**2 + y**2)
                angle = math.atan2(x, y) if y != 0 else 0.0
                self.robot_position = Position(angle=angle, distance=distance)
            
            # Normalize heading
            self.robot_heading = self.robot_heading % (2 * math.pi)
            
        except Exception as e:
            pass
    
    def get_robot_bounds_in_robot_coords(self) -> List[Position]:
        """
        Get robot boundary points in robot coordinates for collision detection
        
        Returns:
            List of Position objects representing robot boundary
        """
        # Define robot corners relative to center
        half_length = self.robot_length / 2
        half_width = self.robot_width / 2
        
        corners = [
            (half_length, half_width),    # Front-right
            (half_length, -half_width),   # Front-left
            (-half_length, -half_width),  # Rear-left
            (-half_length, half_width)    # Rear-right
        ]
        
        robot_bounds = []
        for x, y in corners:
            distance = math.sqrt(x**2 + y**2)
            angle = math.atan2(y, x)
            robot_bounds.append(Position(angle=angle, distance=distance))
        
        return robot_bounds
    
    def add_safety_buffer_to_obstacles(self, obstacles: List[Position], 
                                     buffer_mm: float = 300) -> List[Position]:
        """
        Add safety buffer around obstacles for robot dimensions
        
        Args:
            obstacles: List of obstacle positions
            buffer_mm: Safety buffer in millimeters
            
        Returns:
            List of expanded obstacle positions
        """
        buffered_obstacles = []
        
        for obstacle in obstacles:
            try:
                # Convert to cartesian
                x, y = obstacle.to_cartesian()
                
                # Add buffer points around the obstacle
                buffer_angles = [0, 45, 90, 135, 180, 225, 270, 315]  # 8 directions
                
                for angle_deg in buffer_angles:
                    angle_rad = math.radians(angle_deg)
                    buffer_x = x + buffer_mm * math.cos(angle_rad)
                    buffer_y = y + buffer_mm * math.sin(angle_rad)
                    
                    buffer_distance = math.sqrt(buffer_x**2 + buffer_y**2)
                    buffer_angle = math.atan2(buffer_x, buffer_y) if buffer_y != 0 else 0.0
                    
                    buffered_obstacles.append(Position(angle=buffer_angle, distance=buffer_distance))
                
                # Include original obstacle
                buffered_obstacles.append(obstacle)
                
            except Exception as e:
                # Keep original if buffering fails
                buffered_obstacles.append(obstacle)
        
        return buffered_obstacles
    
    def get_status(self) -> dict:
        """Get current transformer status for debugging"""
        return {
            'robot_position': str(self.robot_position),
            'robot_heading_deg': math.degrees(self.robot_heading),
            'head_angle_deg': math.degrees(self.head_angle),
            'robot_dimensions': f"{self.robot_length}x{self.robot_width}mm",
            'camera_offset': f"({self.camera_x_offset}, {self.camera_y_offset}, {self.camera_z_offset})",
            'lidar_offset': f"({self.lidar_x_offset}, {self.lidar_y_offset}, {self.lidar_z_offset})"
        }