import UltraBorg
from .ActionManager import ActionManager
from ..types.MovementDirection import MovementDirection


class VelocityConfig:
    """
    The configuration for moving the robot.
    Behaviors will pass this to the Velocity Manager to move
    """

    def __init__(self, direction: MovementDirection, speed: int=1) -> None:
        self.direction = direction
        self.speed = speed


    def __str__(self):
        return f"Moving {self.direction.name} ({self.speed})"


class VelocityManager(ActionManager[VelocityConfig]):
    """
    The Action Manager responsible for moving the robot.
    """

    # stores the x, y coordinates to move the servo for each direction of travel
    DIRECTION_TO_SERVO_VALUES = {
        MovementDirection.NONE: (0, 0),
        MovementDirection.FORWARDS: (0.98, 0.24),
        MovementDirection.LEFT: (-0.26, -1.0),
        MovementDirection.RIGHT: (0.1, 0.8),
        MovementDirection.FORWARDS_LEFT: (-0.9, 0.1),
        MovementDirection.FORWARDS_RIGHT: (-0.9, -0.3),
        MovementDirection.BACKWARDS: (-0.95, -0.12),
        MovementDirection.BACKWARDS_LEFT: (0.98, -0.02),
        MovementDirection.BACKWARDS_RIGHT: (0.98, 0.4),
    }

    def __init__(self, i2c_channel) -> None:
        """
        Initiliases the velocity manager.

        args:
            - ic2_channel: The I2C Channel of the joystick actuators
        """
        super().__init__("Velocity Manager")
        self.board = UltraBorg_old.UltraBorg()
        self.board.i2cAddress = i2c_channel
        self.board.Init()

    def perform_action(self, config: VelocityConfig):
        """
        Moves the robot in a direction by setting servo values
        """
        # get servo positions for direction
        direction = config.direction
        x, y = self.DIRECTION_TO_SERVO_VALUES[direction]

        # set servo positions
        self.board.SetServoPosition1(x)
        self.board.SetServoPosition2(y)
